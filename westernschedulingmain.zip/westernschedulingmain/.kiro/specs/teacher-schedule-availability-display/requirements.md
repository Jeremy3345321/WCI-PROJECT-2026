# Requirements Document

## Introduction

This feature enhances the teacher schedule modal in the Teachers tab to provide clear visual indicators of teacher, section, and subject availability. Currently, users find it difficult to make scheduling choices because availability information is not clearly displayed, making it hard to understand which sections and subjects are available for assignment at each time slot.

## Glossary

- **Schedule_Modal**: The modal dialog that appears when clicking the schedule button for a teacher in the Teachers tab
- **Time_Slot**: A specific period in the schedule (e.g., p1, p2, p3) on a specific day
- **Teacher_Availability**: The days and time slots when a teacher has marked themselves as available to teach
- **Section_Availability**: The days and time slots when a section is available for classes
- **Subject_Dropdown**: The dropdown menu for selecting subjects in a time slot
- **Section_Dropdown**: The dropdown menu for selecting sections in a time slot
- **Conflict_Warning**: Visual indicator showing when a section is already assigned to another teacher
- **Department_Filter**: Logic that filters sections based on teacher's department preferences (JHS, SHS, Grade 11, Grade 12)
- **Subject_Filter**: Logic that filters subjects based on teacher's subject list

## Requirements

### Requirement 1: Display Section Availability Status

**User Story:** As a scheduler, I want to see which sections are available vs unavailable in each time slot, so that I can quickly identify valid scheduling options.

#### Acceptance Criteria

1. WHEN a section is available for a time slot, THE Section_Dropdown SHALL display the section name in normal styling
2. WHEN a section is unavailable for a time slot, THE Section_Dropdown SHALL NOT include the section in the dropdown options
3. WHEN a section is already assigned to another teacher at the same time slot, THE Section_Dropdown SHALL display the section with a conflict warning indicator
4. WHEN the Section_Dropdown contains no available sections, THE Section_Dropdown SHALL display a message indicating no sections are available

### Requirement 2: Display Subject Availability Information

**User Story:** As a scheduler, I want to see which subjects are available for selection, so that I can make informed scheduling decisions.

#### Acceptance Criteria

1. WHEN a section is selected, THE Subject_Dropdown SHALL display only subjects that match the selected section's curriculum
2. WHEN a teacher has a subject list defined, THE Subject_Dropdown SHALL display only subjects from the teacher's subject list
3. WHEN a teacher has no subject list defined, THE Subject_Dropdown SHALL display all subjects for the selected section
4. WHEN no section is selected, THE Subject_Dropdown SHALL display a message prompting to select a section first
5. WHEN the Subject_Dropdown contains no available subjects, THE Subject_Dropdown SHALL display a message indicating no subjects are available

### Requirement 3: Display Teacher Unavailability

**User Story:** As a scheduler, I want to clearly see when a teacher is unavailable, so that I don't attempt to schedule them during those times.

#### Acceptance Criteria

1. WHEN a teacher has marked a time slot as unavailable, THE Schedule_Modal SHALL display the time slot cell with a distinct unavailable visual style
2. WHEN a teacher has marked a time slot as unavailable, THE Schedule_Modal SHALL disable both Section_Dropdown and Subject_Dropdown for that time slot
3. WHEN a teacher has marked a time slot as unavailable, THE Schedule_Modal SHALL display "Not Available" text in the time slot cell
4. WHEN a teacher has no availability preferences set, THE Schedule_Modal SHALL treat all time slots as available

### Requirement 4: Display Conflict Warnings

**User Story:** As a scheduler, I want to see clear warnings when a section is already assigned to another teacher, so that I can avoid scheduling conflicts.

#### Acceptance Criteria

1. WHEN a section is already assigned to another teacher at the same time slot, THE Section_Dropdown SHALL display the section with a warning icon (⚠️)
2. WHEN a section is already assigned to another teacher at the same time slot, THE Section_Dropdown SHALL display the section in red text with a light red background
3. WHEN hovering over a conflicting section option, THE Section_Dropdown SHALL display a tooltip showing which teacher the section is assigned to
4. WHEN a section is currently selected by the active teacher, THE Section_Dropdown SHALL NOT display conflict styling for that section

### Requirement 5: Display Department Filter Status

**User Story:** As a scheduler, I want to understand why certain sections are not available, so that I can make appropriate scheduling decisions.

#### Acceptance Criteria

1. WHEN a teacher has department preferences set, THE Section_Dropdown SHALL include only sections matching the teacher's departments
2. WHEN a teacher has JHS department enabled, THE Section_Dropdown SHALL include sections with grade 10 or below
3. WHEN a teacher has SHS and Grade 11 departments enabled, THE Section_Dropdown SHALL include Grade 11 sections
4. WHEN a teacher has SHS and Grade 12 departments enabled, THE Section_Dropdown SHALL include Grade 12 sections
5. WHEN a teacher has no department preferences set, THE Section_Dropdown SHALL include all sections

### Requirement 6: Display Empty State Messages

**User Story:** As a scheduler, I want to see helpful messages when no options are available, so that I understand why I cannot make a selection.

#### Acceptance Criteria

1. WHEN no sections are available for a time slot, THE Section_Dropdown SHALL display "— No Sections Available —" as the only option
2. WHEN no subjects are available for a selected section, THE Subject_Dropdown SHALL display "— No Subjects Available —" as the only option
3. WHEN no section is selected, THE Subject_Dropdown SHALL display "— Select Section First —" as the only option
4. WHEN a time slot is unavailable for the teacher, THE Section_Dropdown SHALL display "— Not Available —" as the only option
5. WHEN a time slot is unavailable for the teacher, THE Subject_Dropdown SHALL display "— Not Available —" as the only option

### Requirement 7: Preserve Visual Consistency

**User Story:** As a scheduler, I want the schedule modal to maintain consistent visual styling, so that I can easily scan and understand the information.

#### Acceptance Criteria

1. THE Schedule_Modal SHALL use consistent color coding for availability states across all time slots
2. THE Schedule_Modal SHALL use consistent icon usage for warnings and status indicators
3. THE Schedule_Modal SHALL maintain readable contrast ratios for all text and background combinations
4. THE Schedule_Modal SHALL use consistent spacing and alignment for dropdown elements
