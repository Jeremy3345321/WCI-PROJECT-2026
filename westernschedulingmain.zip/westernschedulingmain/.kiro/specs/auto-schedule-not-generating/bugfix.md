# Bugfix Requirements Document

## Introduction

The auto-generate feature in the scheduling system fails to generate and save schedules to the database. When users trigger the auto-generate functionality, the system deletes existing schedules but does not create new ones, leaving the schedule table empty. This occurs when the scheduling algorithm fails to generate any assignments due to constraints (no available teachers, no matching subjects, availability conflicts, etc.), but the system still reports success to the user.

The bug impacts users by:
- Clearing existing schedules without replacement
- Providing misleading success messages when no schedules were actually created
- Leaving the system in an inconsistent state with empty schedule data

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN the auto-generate endpoint is called AND the scheduling algorithm produces zero assignments (empty $assignments array) THEN the system deletes all existing schedules from the database, skips the INSERT loop entirely (because the array is empty), and returns a success response with successCount=0

1.2 WHEN the database prepare statement fails (returns false) for the INSERT operation THEN the system attempts to call bind_param() and execute() on a false value, causing PHP errors, but does not report this failure to the user

1.3 WHEN no schedules are generated due to constraint violations (no available teachers, no matching subjects, teacher load limits, availability conflicts) THEN the system still reports "Schedule generated successfully" even though the schedules table is empty

### Expected Behavior (Correct)

2.1 WHEN the auto-generate endpoint is called AND the scheduling algorithm produces zero assignments THEN the system SHALL NOT delete existing schedules and SHALL return an error response indicating that no schedules could be generated with diagnostic information about why (e.g., "No schedules could be generated: no available teachers for required subjects")

2.2 WHEN the database prepare statement fails for the INSERT operation THEN the system SHALL detect this failure, log the error, and return an error response to the user indicating database operation failure

2.3 WHEN no schedules are generated due to constraint violations THEN the system SHALL return an error response with specific details about which constraints prevented schedule generation (e.g., which sections have no available teachers, which subjects have no qualified teachers)

### Unchanged Behavior (Regression Prevention)

3.1 WHEN the auto-generate endpoint is called AND the scheduling algorithm successfully generates one or more assignments THEN the system SHALL CONTINUE TO delete existing schedules, insert the new assignments, and return a success response with accurate statistics

3.2 WHEN schedules are successfully generated but contain conflicts (unit deficits, same-day duplicates, gaps) THEN the system SHALL CONTINUE TO save the schedules and report the conflicts in the response for user review

3.3 WHEN the scheduling algorithm encounters partial failures (some sections scheduled, others not) THEN the system SHALL CONTINUE TO save the successfully generated schedules and report the failed assignments in the response
