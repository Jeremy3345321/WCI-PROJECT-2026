# Requirements Document

## Introduction

This feature automatically calculates teacher working hours (time in and time out) based on their weekly load, assigned teaching schedule, and required non-teaching hours. The system will compute daily working hours to ensure teachers fulfill their weekly load requirements while accounting for their actual class assignments.

## Glossary

- **Teacher**: A faculty member with a weekly load requirement and assigned classes
- **Weekly_Load**: Total hours a teacher must work per week (e.g., 40 hours)
- **Teaching_Schedule**: The assigned classes for a teacher in specific time slots and days
- **Time_Slot**: A period in the schedule (p1-p10) with defined start and end times
- **Working_Hours**: The calculated time in and time out for each day
- **Non_Teaching_Hours**: Additional hours beyond teaching time needed to fulfill daily load
- **Daily_Load**: The portion of weekly load allocated to a specific day
- **Availability_Object**: The per-day time in/out data structure stored in the teacher record
- **Calculator**: The component that computes working hours based on load and schedule

## Requirements

### Requirement 1: Calculate Daily Working Hours

**User Story:** As a teacher, I want my daily working hours to be automatically calculated, so that I know when I should arrive and leave each day.

#### Acceptance Criteria

1. WHEN a teacher has a weekly load and teaching schedule, THE Calculator SHALL compute the daily time in and time out for each working day
2. THE Calculator SHALL distribute the weekly load evenly across working days (weekly load ÷ number of working days)
3. WHEN a teacher has classes on a specific day, THE Calculator SHALL set time in to the start time of the first class
4. WHEN a teacher has classes on a specific day, THE Calculator SHALL calculate time out as time in plus daily load plus break time
5. THE Calculator SHALL account for lunch breaks (30-60 minutes) and other breaks (15 minutes each) when calculating time out

### Requirement 2: Parse Teaching Schedule

**User Story:** As a system administrator, I want the system to parse teacher schedules, so that teaching hours can be extracted for calculations.

#### Acceptance Criteria

1. WHEN a teacher's schedule is loaded, THE Schedule_Parser SHALL extract all assigned time slots for each day
2. THE Schedule_Parser SHALL map time slot IDs (p1-p10) to actual start and end times
3. THE Schedule_Parser SHALL identify the earliest class start time for each day
4. THE Schedule_Parser SHALL calculate total teaching hours per day from assigned slots
5. WHEN a teacher has no classes on a specific day, THE Schedule_Parser SHALL return zero teaching hours for that day

### Requirement 3: Handle Different Time Slot Systems

**User Story:** As a system administrator, I want the system to handle both JHS and SHS time slots, so that calculations are accurate for all grade levels.

#### Acceptance Criteria

1. THE Calculator SHALL use JHS time slots (7:00 AM - 4:30 PM) for teachers with Grade 7-10 classes
2. THE Calculator SHALL use SHS time slots (7:30 AM - 5:30 PM) for teachers with Grade 11-12 classes
3. WHEN a teacher has both JHS and SHS classes, THE Calculator SHALL use the earliest start time and latest end time
4. THE Calculator SHALL correctly map period IDs (p1-p10) to their corresponding time ranges based on grade level

### Requirement 4: Update Availability Object

**User Story:** As a teacher, I want my availability to be automatically updated with calculated hours, so that the system reflects my actual working schedule.

#### Acceptance Criteria

1. WHEN working hours are calculated, THE Calculator SHALL update the teacher's availability object with time in and time out for each day
2. THE Calculator SHALL preserve the availability object structure with timeIn and timeOut fields
3. THE Calculator SHALL only update days where the teacher has classes or is required to work
4. WHEN a teacher has no classes on a day, THE Calculator SHALL not set availability for that day unless required by weekly load distribution

### Requirement 5: Handle Edge Cases

**User Story:** As a system administrator, I want the system to handle edge cases gracefully, so that calculations remain accurate in unusual scenarios.

#### Acceptance Criteria

1. WHEN a teacher has zero or empty weekly load, THE Calculator SHALL not modify the availability object
2. WHEN a teacher has no assigned classes, THE Calculator SHALL distribute weekly load evenly across standard working days (Monday-Friday)
3. WHEN calculated time out exceeds reasonable working hours (after 6:00 PM), THE Calculator SHALL cap time out at 6:00 PM and log a warning
4. WHEN a teacher's teaching hours exceed their daily load, THE Calculator SHALL set time out to the end of the last class
5. IF calculation fails due to invalid data, THEN THE Calculator SHALL return an error message and preserve existing availability

### Requirement 6: Provide Calculation Transparency

**User Story:** As a teacher, I want to see how my working hours were calculated, so that I can understand and verify the results.

#### Acceptance Criteria

1. THE Calculator SHALL provide a breakdown showing weekly load, daily load, teaching hours, and non-teaching hours
2. THE Calculator SHALL display the calculation formula used for each day
3. WHEN working hours are displayed in the UI, THE System SHALL show both calculated values and the breakdown
4. THE Calculator SHALL indicate which days have automatic calculations versus manual overrides

### Requirement 7: Support Manual Override

**User Story:** As a teacher, I want to manually override calculated working hours, so that I can adjust for special circumstances.

#### Acceptance Criteria

1. THE System SHALL allow teachers to manually edit time in and time out fields
2. WHEN a manual override is applied, THE System SHALL mark that day as manually set
3. THE System SHALL provide a button to recalculate and restore automatic values
4. WHEN recalculation is triggered, THE System SHALL replace manual overrides with newly calculated values

### Requirement 8: Integrate with Existing UI

**User Story:** As a user, I want the automatic calculation to work seamlessly with the existing teacher edit interface, so that the experience is intuitive.

#### Acceptance Criteria

1. WHEN the teacher edit modal opens, THE System SHALL automatically calculate and display working hours
2. THE System SHALL update working hours whenever the weekly load field changes
3. THE System SHALL update working hours whenever the teaching schedule changes
4. THE System SHALL maintain the existing per-day time in/out UI layout
5. THE System SHALL add a visual indicator (icon or label) showing that hours are automatically calculated

### Requirement 9: Display Working Hours in Schedule View

**User Story:** As a teacher, I want to see my daily working hours (time in - time out) displayed in my schedule, so that I know my full workday at a glance.

#### Acceptance Criteria

1. WHEN viewing a teacher's schedule in the schedule modal, THE System SHALL display the time in and time out for each day at the bottom or top of that day's column
2. THE System SHALL format the display as "Time In - Time Out" (e.g., "7:30 AM - 5:30 PM")
3. WHEN a teacher has no availability set for a day, THE System SHALL not display working hours for that day
4. THE System SHALL display working hours even if the teacher's classes end earlier than the time out
5. THE System SHALL visually distinguish working hours from class time slots (e.g., using different styling or positioning)

### Requirement 10: Include Working Hours in PDF Exports

**User Story:** As a teacher, I want my working hours to appear in PDF exports of my schedule, so that printed schedules show my complete workday.

#### Acceptance Criteria

1. WHEN exporting a teacher's schedule to PDF, THE System SHALL include time in and time out for each working day
2. THE System SHALL position working hours prominently (e.g., at the top or bottom of each day column)
3. THE System SHALL format working hours consistently with the on-screen display
4. WHEN generating a master schedule PDF with all teachers, THE System SHALL include working hours for each teacher
5. THE PDF export SHALL maintain readability with working hours included

### Requirement 11: Include Working Hours in Excel Exports

**User Story:** As an administrator, I want working hours included in Excel exports, so that I can analyze teacher workloads and schedules.

#### Acceptance Criteria

1. WHEN exporting a teacher's schedule to Excel, THE System SHALL include a row or cell showing time in and time out for each day
2. THE System SHALL format time values in Excel as time data type (not text) for calculations
3. WHEN exporting multiple teachers to Excel, THE System SHALL include working hours for each teacher
4. THE Excel export SHALL include a column or section clearly labeled "Working Hours" or "Time In/Out"
5. THE System SHALL allow filtering and sorting by working hours in the Excel export

### Requirement 12: Include Working Hours in All Printables

**User Story:** As a user, I want working hours to appear in all printable formats, so that any printed schedule shows complete information.

#### Acceptance Criteria

1. THE System SHALL include working hours in all printable schedule formats (individual teacher, section, master schedule)
2. WHEN printing a teacher's schedule, THE System SHALL show time in and time out for each working day
3. THE System SHALL maintain consistent formatting of working hours across all printable formats
4. WHEN printing section schedules that show teacher assignments, THE System SHALL optionally include teacher working hours
5. THE System SHALL ensure working hours do not clutter or obscure the main schedule information in printables
