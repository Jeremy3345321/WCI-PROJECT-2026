# Design Document: Teacher Working Hours Calculation

## Overview

This feature automatically calculates teacher working hours (time in and time out) for each working day based on three inputs:
1. Weekly load (total hours per week, e.g., 40 hours)
2. Teaching schedule (assigned classes in specific time slots)
3. Required non-teaching hours (preparation, grading, meetings)

The system computes when teachers should arrive and leave each day to fulfill their weekly load while accounting for their actual class assignments. This eliminates manual time entry and ensures consistency between teaching schedules and working hours.

The calculation follows this logic:
- Daily load = Weekly load ÷ Number of working days
- Time in = Start time of first class
- Time out = Time in + Daily load (including breaks)

## Architecture

### System Context

```mermaid
graph TB
    UI[Teacher Edit Modal] --> Calculator[Working Hours Calculator]
    Schedule[Schedule Data] --> Calculator
    Calculator --> Availability[Availability Object]
    Availability --> Display[Schedule Views]
    Availability --> Export[PDF/Excel Exports]
    Availability --> Print[Printables]
```

### Component Architecture

```mermaid
graph LR
    A[Schedule Parser] --> B[Time Slot Mapper]
    B --> C[Hours Calculator]
    C --> D[Availability Updater]
    D --> E[UI Renderer]
    
    F[Teacher Data] --> A
    G[Time Slot Definitions] --> B
    H[Weekly Load] --> C
```

The system consists of five main components:

1. **Schedule Parser**: Extracts teaching assignments from schedule data
2. **Time Slot Mapper**: Maps period IDs (p1-p10) to actual times based on grade level
3. **Hours Calculator**: Computes daily working hours from load and schedule
4. **Availability Updater**: Updates teacher availability object with calculated hours
5. **UI Renderer**: Displays working hours in various views and exports

### Data Flow

```mermaid
sequenceDiagram
    participant UI
    participant Calculator
    participant Parser
    participant Mapper
    participant Updater
    
    UI->>Calculator: Calculate hours (teacherId, weeklyLoad)
    Calculator->>Parser: Parse schedule
    Parser-->>Calculator: Teaching assignments by day
    Calculator->>Mapper: Map time slots to times
    Mapper-->>Calculator: Actual start/end times
    Calculator->>Calculator: Compute daily hours
    Calculator->>Updater: Update availability
    Updater-->>UI: Updated teacher object
```

## Components and Interfaces

### 1. Schedule Parser

**Purpose**: Extract teaching assignments from schedule data structure

**Interface**:
```javascript
/**
 * Parse teacher's schedule to extract teaching assignments
 * @param {string} teacherId - Teacher ID
 * @param {Object} scheduleCache - Global schedule cache object
 * @returns {Object} Teaching assignments by day
 */
function parseTeacherSchedule(teacherId, scheduleCache) {
    // Returns: {
    //   Monday: [{ slotId: 'p1', section: 'G7-A', subject: 'Math' }, ...],
    //   Tuesday: [...],
    //   ...
    // }
}
```

**Responsibilities**:
- Access schedule cache for specific teacher
- Extract all assigned slots for each day
- Filter out empty/unassigned slots
- Return structured assignment data

### 2. Time Slot Mapper

**Purpose**: Map period IDs to actual start and end times based on grade level

**Interface**:
```javascript
/**
 * Get time slot definition for a period ID
 * @param {string} slotId - Period ID (p1-p10)
 * @param {boolean} isJHS - Whether to use JHS time slots
 * @returns {Object} Time slot with start and end times
 */
function getTimeSlot(slotId, isJHS) {
    // Returns: { id: 'p1', start: '7:00 AM', end: '7:30 AM', minutes: 30 }
}

/**
 * Determine if teacher teaches JHS or SHS based on schedule
 * @param {Object} assignments - Teaching assignments by day
 * @param {Array} sections - All sections data
 * @returns {boolean} True if teacher has any JHS classes
 */
function teachesJHS(assignments, sections) {
    // Returns: true if any assigned section has grade <= 10
}
```

**Responsibilities**:
- Provide time slot definitions for JHS (7:00 AM - 4:30 PM)
- Provide time slot definitions for SHS (7:30 AM - 5:30 PM)
- Determine which time slot system to use based on teacher's classes
- Handle mixed JHS/SHS schedules (use earliest start, latest end)

**Time Slot Definitions**:

JHS (Grades 7-10):
- p1: 7:00 - 7:30 AM (30 min)
- p2: 7:30 - 8:30 AM (60 min)
- p3: 8:30 - 9:30 AM (60 min)
- Break: 9:30 - 9:45 AM (15 min)
- p4: 9:45 - 10:45 AM (60 min)
- p5: 10:45 - 11:45 AM (60 min)
- Lunch: 11:45 AM - 12:15 PM (30 min)
- p6: 12:15 - 1:15 PM (60 min)
- p7: 1:15 - 2:15 PM (60 min)
- Break: 2:15 - 2:30 PM (15 min)
- p8: 2:30 - 3:30 PM (60 min)
- p9: 3:30 - 4:30 PM (60 min)

SHS (Grades 11-12):
- p2: 7:30 - 8:30 AM (60 min)
- p3: 8:30 - 9:30 AM (60 min)
- p4: 9:30 - 10:30 AM (60 min)
- Break: 10:30 - 10:45 AM (15 min)
- p5: 10:45 - 11:45 AM (60 min)
- p6: 11:45 AM - 12:45 PM (60 min)
- Lunch: 12:45 - 1:15 PM (30 min)
- p7: 1:15 - 2:15 PM (60 min)
- p8: 2:15 - 3:15 PM (60 min)
- Break: 3:15 - 3:30 PM (15 min)
- p9: 3:30 - 4:30 PM (60 min)
- p10: 4:30 - 5:30 PM (60 min)

### 3. Hours Calculator

**Purpose**: Compute daily working hours from weekly load and teaching schedule

**Interface**:
```javascript
/**
 * Calculate working hours for all working days
 * @param {number} weeklyLoad - Total hours per week (e.g., 40)
 * @param {Object} assignments - Teaching assignments by day
 * @param {Object} timeSlotMapper - Time slot mapper instance
 * @returns {Object} Calculated hours by day
 */
function calculateWorkingHours(weeklyLoad, assignments, timeSlotMapper) {
    // Returns: {
    //   Monday: { timeIn: '07:00', timeOut: '17:00', breakdown: {...} },
    //   Tuesday: { timeIn: '07:30', timeOut: '16:30', breakdown: {...} },
    //   ...
    // }
}

/**
 * Calculate daily load (hours per day)
 * @param {number} weeklyLoad - Total hours per week
 * @param {Array} workingDays - Days with classes or required work
 * @returns {number} Hours per day
 */
function calculateDailyLoad(weeklyLoad, workingDays) {
    // Returns: weeklyLoad / workingDays.length
}

/**
 * Find earliest class start time for a day
 * @param {Array} dayAssignments - Assignments for one day
 * @param {Object} timeSlotMapper - Time slot mapper instance
 * @returns {string} Time in 24-hour format (e.g., '07:00')
 */
function findEarliestClass(dayAssignments, timeSlotMapper) {
    // Returns: '07:00' or null if no classes
}

/**
 * Calculate time out from time in and daily load
 * @param {string} timeIn - Time in (24-hour format)
 * @param {number} dailyLoad - Hours to work
 * @param {Array} breaks - Break periods to account for
 * @returns {string} Time out (24-hour format)
 */
function calculateTimeOut(timeIn, dailyLoad, breaks) {
    // Returns: '17:00' (capped at 18:00 if exceeds)
}
```

**Calculation Logic**:

1. **Determine working days**: Days with classes or required by weekly load distribution
2. **Calculate daily load**: `weeklyLoad ÷ numberOfWorkingDays`
3. **For each working day**:
   - Find earliest class start time → `timeIn`
   - Calculate total teaching hours for the day
   - Calculate non-teaching hours: `dailyLoad - teachingHours`
   - Calculate `timeOut`: `timeIn + dailyLoad + breaks`
   - Cap `timeOut` at 6:00 PM (18:00) with warning if exceeded

**Break Accounting**:
- Lunch break: 30 minutes (JHS) or 30 minutes (SHS)
- Short breaks: 15 minutes each (2 breaks per day)
- Total break time: 60 minutes per day
- Breaks are added to time out calculation but not counted as working hours

### 4. Availability Updater

**Purpose**: Update teacher's availability object with calculated hours

**Interface**:
```javascript
/**
 * Update teacher availability with calculated hours
 * @param {Object} teacher - Teacher object
 * @param {Object} calculatedHours - Hours by day from calculator
 * @returns {Object} Updated availability object
 */
function updateAvailability(teacher, calculatedHours) {
    // Returns: {
    //   Monday: { available: true, timeIn: '07:00', timeOut: '17:00' },
    //   Tuesday: { available: true, timeIn: '07:30', timeOut: '16:30' },
    //   ...
    // }
}
```

**Responsibilities**:
- Preserve existing availability structure
- Update only days with calculated hours
- Maintain `available`, `timeIn`, `timeOut` fields
- Clear availability for days with no classes (unless required by load)

### 5. UI Integration

**Purpose**: Display working hours in teacher edit modal and schedule views

**Components to Update**:

1. **Teacher Edit Modal** (`edit_teacher_modal.js` / `app.js`):
   - Add "Calculate Hours" button or auto-calculate on load
   - Display calculated hours in time in/out fields
   - Show calculation breakdown (tooltip or expandable section)
   - Add visual indicator for auto-calculated vs manual values
   - Trigger recalculation when weekly load changes

2. **Schedule Modal** (teacher schedule view):
   - Display working hours at top or bottom of each day column
   - Format: "7:30 AM - 5:30 PM"
   - Style differently from class time slots
   - Show only for days with availability set

3. **PDF Export** (`buildTeacherPage` function):
   - Add working hours row/section to teacher schedule PDF
   - Position prominently (below schedule table)
   - Maintain consistent formatting with on-screen display

4. **Excel Export**:
   - Add "Working Hours" column or row
   - Format times as Excel time data type
   - Include for all teachers in multi-teacher exports

5. **Printables** (all schedule print functions):
   - Include working hours in all printable formats
   - Ensure readability and consistent formatting
   - Don't obscure main schedule information

## Data Models

### Teacher Object (Extended)

```javascript
{
  id: "TEACHER_ID",
  name: "Teacher Name",
  load: "40",  // Weekly load in hours (string)
  subjects: ["Math", "Science"],
  availability: {
    Monday: {
      available: true,
      timeIn: "07:00",    // 24-hour format
      timeOut: "17:00",   // 24-hour format
      autoCalculated: true  // NEW: indicates if calculated vs manual
    },
    Tuesday: { ... },
    // ... other days
  },
  // ... other fields
}
```

### Schedule Cache Structure

```javascript
{
  "TEACHER_ID": {
    "Monday": {
      "p1": { section: "G7-A", subject: "Math" },
      "p2": { section: "G7-A", subject: "Math" },
      // ... other slots
    },
    "Tuesday": { ... },
    // ... other days
  }
}
```

### Calculated Hours Object

```javascript
{
  Monday: {
    timeIn: "07:00",
    timeOut: "17:00",
    breakdown: {
      dailyLoad: 8,           // hours
      teachingHours: 5.5,     // hours
      nonTeachingHours: 2.5,  // hours
      breaks: 1,              // hours (not counted in load)
      firstClass: "07:00",
      lastClass: "15:30"
    }
  },
  // ... other days
}
```

### Time Slot Object

```javascript
{
  id: "p1",
  label: "7:00 – 7:30 AM",
  type: "period",  // or "break"
  start: "07:00",  // 24-hour format
  end: "07:30",    // 24-hour format
  minutes: 30
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Daily Load Distribution

*For any* valid weekly load and set of working days, the sum of daily loads SHALL equal the weekly load (dailyLoad × numberOfWorkingDays = weeklyLoad).

**Validates: Requirements 1.2**

### Property 2: Time In Matches Earliest Class

*For any* day with assigned classes, the calculated time in SHALL equal the start time of the earliest class on that day.

**Validates: Requirements 1.3**

### Property 3: Time Out Calculation

*For any* day with assigned classes, the calculated time out SHALL equal time in plus daily load plus break time (60 minutes), capped at 6:00 PM.

**Validates: Requirements 1.4, 1.5, 5.3**

### Property 4: Schedule Extraction Completeness

*For any* teacher schedule in the schedule cache, the parser SHALL extract all non-empty slot assignments for each day.

**Validates: Requirements 2.1**

### Property 5: Slot ID to Time Mapping

*For any* valid slot ID (p1-p10) and grade level (JHS or SHS), the mapper SHALL return the correct time slot definition with start time, end time, and duration.

**Validates: Requirements 2.2, 3.4**

### Property 6: Earliest Class Identification

*For any* non-empty set of class assignments on a day, the parser SHALL correctly identify the earliest class start time.

**Validates: Requirements 2.3**

### Property 7: Teaching Hours Calculation

*For any* set of assigned time slots on a day, the parser SHALL correctly calculate the total teaching hours by summing the duration of all assigned slots.

**Validates: Requirements 2.4**

### Property 8: Time Slot System Selection

*For any* teacher schedule, the calculator SHALL use JHS time slots if the teacher has any Grade 7-10 classes, SHS time slots if the teacher has only Grade 11-12 classes, and the union of both (earliest start, latest end) if the teacher has mixed classes.

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 9: Availability Object Update

*For any* calculated working hours, the updater SHALL correctly update the teacher's availability object with timeIn and timeOut for each working day while preserving the object structure.

**Validates: Requirements 4.1, 4.2**

### Property 10: Selective Day Updates

*For any* teacher schedule, the calculator SHALL only set availability for days where the teacher has classes or is required to work based on weekly load distribution.

**Validates: Requirements 4.3, 4.4**

### Property 11: Empty Schedule Distribution

*For any* teacher with a valid weekly load but no assigned classes, the calculator SHALL distribute the weekly load evenly across Monday through Friday.

**Validates: Requirements 5.2**

### Property 12: Teaching Hours Exceed Daily Load

*For any* day where teaching hours exceed the daily load, the calculator SHALL set time out to the end time of the last class.

**Validates: Requirements 5.4**

### Property 13: Error Handling Preserves Data

*For any* invalid input data (null, undefined, malformed), the calculator SHALL return an error and preserve the existing availability object without modification.

**Validates: Requirements 5.5**

### Property 14: Calculation Breakdown Completeness

*For any* successful calculation, the result SHALL include a breakdown object containing weeklyLoad, dailyLoad, teachingHours, nonTeachingHours, breaks, firstClass, and lastClass fields.

**Validates: Requirements 6.1**

### Property 15: Manual Override Tracking

*For any* day where a manual override is applied, the system SHALL set the autoCalculated flag to false, and when recalculation is triggered, SHALL reset the flag to true and replace the values.

**Validates: Requirements 6.4, 7.2, 7.4**

### Property 16: Time Format Consistency

*For any* time in and time out values, the display format SHALL be consistent across all views (schedule modal, PDF exports, Excel exports, printables) as "HH:MM AM/PM – HH:MM AM/PM".

**Validates: Requirements 9.2, 10.3, 12.3**

### Property 17: Conditional Display

*For any* teacher with partial availability (some days set, some not), the system SHALL display working hours only for days where availability is set.

**Validates: Requirements 9.3**

### Property 18: Display Independent of Class End Time

*For any* day where classes end before the calculated time out, the system SHALL still display the full working hours (time in to time out).

**Validates: Requirements 9.4**

### Property 19: Excel Time Data Type

*For any* time value exported to Excel, the system SHALL format it as Excel's time data type (not text) to enable calculations and sorting.

**Validates: Requirements 11.2**

## Error Handling

### Input Validation

The calculator must validate all inputs before processing:

1. **Weekly Load Validation**:
   - Must be a positive number
   - Reasonable range: 1-60 hours per week
   - Empty or zero load: skip calculation, preserve existing availability

2. **Schedule Data Validation**:
   - Schedule cache must be an object
   - Teacher ID must exist in cache
   - Day names must be valid (Monday-Saturday)
   - Slot IDs must be valid (p1-p10)

3. **Time Slot Validation**:
   - Slot ID must exist in time slot definitions
   - Start time must be before end time
   - Times must be valid 24-hour format

### Error Scenarios

1. **Invalid Weekly Load**:
   - Error: "Invalid weekly load: must be a positive number"
   - Action: Preserve existing availability, return error

2. **Missing Schedule Data**:
   - Error: "Schedule data not found for teacher"
   - Action: Use default distribution (Mon-Fri), continue calculation

3. **Invalid Time Slot**:
   - Error: "Invalid time slot ID: {slotId}"
   - Action: Skip invalid slot, log warning, continue with valid slots

4. **Time Out Exceeds Maximum**:
   - Warning: "Calculated time out ({timeOut}) exceeds 6:00 PM, capped at 6:00 PM"
   - Action: Cap time out at 18:00, log warning, continue

5. **Teaching Hours Exceed Daily Load**:
   - Warning: "Teaching hours ({teachingHours}) exceed daily load ({dailyLoad})"
   - Action: Set time out to end of last class, log warning, continue

### Error Response Format

```javascript
{
  success: false,
  error: "Error message",
  code: "ERROR_CODE",
  preservedData: { /* original availability */ }
}
```

### Success Response Format

```javascript
{
  success: true,
  availability: { /* updated availability object */ },
  breakdown: {
    Monday: {
      dailyLoad: 8,
      teachingHours: 5.5,
      nonTeachingHours: 2.5,
      breaks: 1,
      firstClass: "07:00",
      lastClass: "15:30"
    },
    // ... other days
  },
  warnings: [
    "Time out capped at 6:00 PM for Tuesday"
  ]
}
```

## Testing Strategy

### Unit Tests

Unit tests will verify specific examples, edge cases, and error conditions:

1. **Calculation Examples**:
   - Teacher with 40-hour load, 5 working days → 8 hours per day
   - Teacher with 30-hour load, 3 working days → 10 hours per day
   - Teacher with classes 7:00 AM - 12:00 PM, 8-hour load → time out at 3:00 PM (with breaks)

2. **Edge Cases**:
   - Zero weekly load → no changes to availability
   - Empty schedule → distribute across Mon-Fri
   - Single day schedule → all hours on one day
   - Teaching hours exceed daily load → time out = end of last class
   - Time out exceeds 6:00 PM → capped at 6:00 PM

3. **Time Slot System Selection**:
   - JHS-only teacher → uses JHS time slots (7:00 AM start)
   - SHS-only teacher → uses SHS time slots (7:30 AM start)
   - Mixed JHS/SHS teacher → uses earliest start (7:00 AM)

4. **Error Handling**:
   - Invalid weekly load (negative, non-numeric) → error returned
   - Missing schedule data → uses default distribution
   - Invalid slot ID → skips invalid slot, continues

5. **UI Integration**:
   - Modal opens → hours calculated automatically
   - Weekly load changes → hours recalculated
   - Manual override → autoCalculated flag set to false
   - Recalculate button → overrides replaced with calculated values

### Property-Based Tests

Property-based tests will verify universal properties across many generated inputs using **fast-check** (JavaScript property-based testing library).

Each property test will run a minimum of 100 iterations with randomly generated inputs.

**Test Configuration**:
```javascript
import fc from 'fast-check';

// Run each property test with 100 iterations
const testConfig = { numRuns: 100 };
```

**Property Test Implementation**:

Each correctness property will be implemented as a single property-based test with a comment tag referencing the design document:

```javascript
// Feature: teacher-working-hours-calculation, Property 1: Daily Load Distribution
test('daily load distribution equals weekly load', () => {
  fc.assert(
    fc.property(
      fc.integer({ min: 1, max: 60 }), // weeklyLoad
      fc.integer({ min: 1, max: 6 }),  // numberOfWorkingDays
      (weeklyLoad, numDays) => {
        const dailyLoad = calculateDailyLoad(weeklyLoad, numDays);
        const totalLoad = dailyLoad * numDays;
        // Allow small floating point error
        return Math.abs(totalLoad - weeklyLoad) < 0.01;
      }
    ),
    testConfig
  );
});
```

**Generators**:

Custom generators will be created for domain-specific data:

```javascript
// Generate valid teacher schedule
const teacherScheduleArb = fc.record({
  Monday: fc.array(slotAssignmentArb),
  Tuesday: fc.array(slotAssignmentArb),
  // ... other days
});

// Generate slot assignment
const slotAssignmentArb = fc.record({
  slotId: fc.constantFrom('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10'),
  section: fc.string({ minLength: 1, maxLength: 10 }),
  subject: fc.string({ minLength: 1, maxLength: 20 })
});

// Generate time in 24-hour format
const time24Arb = fc.record({
  hour: fc.integer({ min: 0, max: 23 }),
  minute: fc.integer({ min: 0, max: 59 })
}).map(({ hour, minute }) => 
  `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
);
```

**Property Test Tags**:

Each property test will include a comment tag in the format:
```javascript
// Feature: teacher-working-hours-calculation, Property {number}: {property title}
```

This ensures traceability between design properties and test implementation.

### Integration Tests

Integration tests will verify the feature works correctly with the existing system:

1. **Teacher Edit Modal Integration**:
   - Open modal → hours calculated and displayed
   - Change weekly load → hours recalculated
   - Save teacher → availability persisted to database

2. **Schedule View Integration**:
   - View teacher schedule → working hours displayed
   - Teacher with no availability → no hours shown
   - Teacher with partial availability → hours shown for set days only

3. **PDF Export Integration**:
   - Export teacher schedule → working hours included in PDF
   - Export master schedule → all teachers have working hours
   - PDF format matches screen format

4. **Excel Export Integration**:
   - Export teacher schedule → working hours in Excel with time data type
   - Export multiple teachers → all have working hours
   - Excel times support filtering and sorting

5. **Printables Integration**:
   - Print teacher schedule → working hours included
   - Print section schedule → teacher hours optionally included
   - Print master schedule → all teachers have working hours

### Test Coverage Goals

- Unit test coverage: 90%+ for calculation logic
- Property test coverage: All 19 correctness properties implemented
- Integration test coverage: All UI components and export formats
- Edge case coverage: All error scenarios and boundary conditions

