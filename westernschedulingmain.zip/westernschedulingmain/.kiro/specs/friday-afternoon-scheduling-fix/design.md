# Friday Afternoon Scheduling Fix — Bugfix Design

## Overview

The auto-scheduler in `api/auto_schedule.php` leaves Friday afternoon slots (p7, p8, p9) empty
for subjects with ≤5 units even when the teacher is available and the subject still has an unmet
weekly unit requirement. The root cause is a hard `maxPeriodsPerDay = 1` cap that is enforced
unconditionally in both the first pass and the second pass (SKIP slot recovery), with no exception
for the case where a subject has a remaining deficit and no other slot can satisfy it.

The fix relaxes the daily cap in exactly two targeted places:
1. **First pass** — when the target slot is a Friday afternoon slot (p7/p8/p9) and the subject
   still has a deficit, allow a second period on that day.
2. **Second pass** — when processing a SKIP slot and the subject has a deficit, allow it to
   exceed the 1-per-day limit so the weekly requirement can be fulfilled.

All other scheduling constraints (teacher availability, back-to-back prevention, unit cap) remain
fully enforced.

## Glossary

- **Bug_Condition (C)**: The condition that triggers the bug — a subject with ≤5 units has a
  remaining weekly deficit AND the only available slot is a Friday afternoon slot (p7/p8/p9) or a
  SKIP slot where the subject already has 1 period on that day.
- **Property (P)**: The desired behavior — when C holds, the scheduler SHALL assign the subject to
  the available slot rather than skip it.
- **Preservation**: All scheduling behavior for inputs where C does NOT hold must remain identical
  to the original code.
- **maxPeriodsPerDay**: The per-subject daily period cap. Currently hard-coded to 1 for subjects
  with ≤5 units; the fix conditionally raises it to 2 when a deficit exists and no other slot is
  available.
- **SKIP marker**: A sentinel value (`'SKIP'`) written into `$sectionSchedule` when the first pass
  cannot fill a slot. The second pass iterates over SKIP slots to attempt recovery.
- **deficit**: `$requiredUnits - $currentUnits` for a subject within a section for the current
  week. A positive deficit means the subject still needs more periods.
- **isLateWeekSlot**: Boolean — true when `$targetDay === 'Friday'` and `$targetSlot` is one of
  `['p7', 'p8', 'p9']`.

## Bug Details

### Bug Condition

The bug manifests when the sequential slot scan reaches a Friday afternoon slot (or a SKIP slot
on any day) and the highest-priority subject already has 1 period assigned on that day. The daily
limit check fires before the back-to-back check and unconditionally skips the subject, even though
the subject has a remaining deficit and the teacher is available.

**Formal Specification:**
```
FUNCTION isBugCondition(subjectInfo, targetDay, targetSlot, subjectUsagePerDay, sectionId)
  INPUT:
    subjectInfo   — { name, units (requiredUnits), current (currentUnits), deficit }
    targetDay     — string day name
    targetSlot    — string slot id
    subjectUsagePerDay — usage tracking map
    sectionId     — section identifier
  OUTPUT: boolean

  usageToday := subjectUsagePerDay[sectionId][targetDay][subjectInfo.name] ?? 0

  RETURN subjectInfo.units <= 5
         AND subjectInfo.deficit > 0
         AND usageToday >= 1
         AND (
               (targetDay = 'Friday' AND targetSlot IN ['p7','p8','p9'])
               OR targetSlot IS SKIP_SLOT
             )
END FUNCTION
```

### Examples

- **Example 1 — First pass, Friday afternoon**: Subject "Mathematics" has 5 units. Monday–Thursday
  each got 1 period (4 total). Friday p2 was skipped (teacher conflict). The scan reaches Friday
  p7; `usageToday = 0`, so the daily limit is not the issue here — but if Friday p2 was assigned
  and p7 is reached with `usageToday = 1`, the cap blocks the 5th period. Expected: assign p7.
  Actual (buggy): skip p7, subject ends the week with 4 periods.

- **Example 2 — Second pass, SKIP slot**: Subject "Science" has 5 units. First pass assigned 4
  periods (Mon–Thu, 1 each). Friday p2 was marked SKIP (no available teacher at that time). Second
  pass finds the SKIP slot on Friday p2; `usageToday = 0` so the daily limit is not the blocker
  here. But if Friday p2 was assigned in the first pass and p7 is the SKIP slot, `usageToday = 1`
  and the second pass still enforces `maxPeriodsPerDay = 1`, blocking recovery. Expected: assign
  the SKIP slot. Actual (buggy): skip it, subject ends with 4 periods.

- **Example 3 — Deficit + only Friday afternoon available**: All Monday–Thursday slots are filled
  by other subjects. The only remaining empty slot for the section is Friday p8. Subject has
  deficit = 1 and `usageToday = 1` (already placed at Friday p2). Expected: assign Friday p8.
  Actual (buggy): daily cap blocks it, slot stays empty.

- **Edge case — No deficit**: Subject "Filipino" has 5 units, all 5 already assigned. Friday p7
  is empty. Expected: system correctly refuses to assign a 6th period. Fix must NOT change this.

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- A subject that has already met its exact weekly unit requirement SHALL NOT receive additional
  assignments, regardless of available slots.
- Teacher availability checks SHALL continue to gate every assignment in both passes.
- The `wouldCreateBackToBackPeriods()` check SHALL continue to run after the daily limit check
  passes; the fix only relaxes the daily cap, not the back-to-back rule (except the existing
  `$isLateWeekSlot` flexibility already present in the function).
- JHS sections SHALL continue to be restricted to Monday–Friday only; Saturday assignments for
  JHS remain blocked.
- Subjects with 6+ units SHALL continue to allow up to 2 periods per day unchanged.
- Mouse-click and manual schedule interactions are unaffected (server-side only change).

**Scope:**
All inputs where `isBugCondition` returns false — i.e., the subject has no deficit, or the slot
is not a Friday afternoon / SKIP slot, or the subject already has 0 periods today — are completely
unaffected by this fix.

## Hypothesized Root Cause

1. **Unconditional daily cap in first pass (~line 620–630)**: The block
   ```php
   if ($requiredUnits <= 5) { $maxPeriodsPerDay = 1; }
   if ($subjectUsageToday >= $maxPeriodsPerDay) { continue; }
   ```
   runs before any deficit-awareness check. There is no branch that says "but if this is the only
   remaining slot and the subject has a deficit, allow it."

2. **Same unconditional cap duplicated in second pass (~line 960–970)**: The SKIP slot recovery
   loop copies the identical logic verbatim. The comment even says "relaxed daily limits" but the
   code does not actually relax them for ≤5-unit subjects.

3. **`$isLateWeekSlot` flexibility exists only for back-to-back, not for the daily cap**: The
   `wouldCreateBackToBackPeriods()` function already accepts `$isLateWeekSlot` and applies looser
   rules, but the daily cap check that precedes it has no equivalent flexibility.

4. **SKIP marker prevents re-scan**: Once a slot is marked SKIP, the first pass skips it on every
   subsequent iteration. If the second pass also cannot place a subject (due to the daily cap), the
   slot remains permanently empty with no further retry.

## Correctness Properties

Property 1: Bug Condition — Deficit Subjects Fill Available Slots

_For any_ subject where `isBugCondition` returns true (units ≤5, positive deficit, already has 1
period today, and the target slot is a Friday afternoon slot or a SKIP slot), the fixed scheduler
SHALL assign the subject to that slot when a qualified, available teacher exists, ensuring the
weekly unit requirement is fully met.

**Validates: Requirements 2.1, 2.2, 2.3**

Property 2: Preservation — Non-Deficit and Non-Buggy-Slot Behavior Unchanged

_For any_ scheduling decision where `isBugCondition` returns false (subject has no deficit, OR
the slot is not a Friday afternoon / SKIP slot, OR the subject has 0 periods today), the fixed
scheduler SHALL produce exactly the same assignment decisions as the original code, preserving all
existing distribution, conflict-avoidance, and unit-cap behavior.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**

## Fix Implementation

### Changes Required

**File**: `api/auto_schedule.php`

**First Pass — ~line 620–630**

**Specific Changes**:

1. **Add deficit-aware relaxation before the daily cap check**: After computing `$maxPeriodsPerDay`,
   add a conditional that raises it to 2 when the slot is a Friday afternoon slot AND the subject
   has a remaining deficit:
   ```php
   // Relax daily cap for Friday afternoon slots when subject has a deficit
   $isLateWeekSlot = ($targetDay === 'Friday' && in_array($targetSlot, ['p7', 'p8', 'p9']));
   if ($isLateWeekSlot && $subjInfo['deficit'] > 0 && $maxPeriodsPerDay === 1) {
       $maxPeriodsPerDay = 2;
   }
   ```
   This block is inserted immediately after the `$maxPeriodsPerDay` assignment and before the
   `if ($subjectUsageToday >= $maxPeriodsPerDay) { continue; }` guard.

   Note: The existing `$isLateWeekSlot` variable computed a few lines later (for back-to-back
   rules) should be removed or merged to avoid duplication.

**Second Pass — ~line 960–970**

2. **Apply the same relaxation in the SKIP slot recovery loop**: In the second pass, the SKIP slot
   is already a "last resort" recovery attempt. Relax the cap whenever the subject has a deficit,
   regardless of which day/slot the SKIP falls on:
   ```php
   // In second pass: relax daily cap whenever subject has a deficit (SKIP recovery)
   if ($subjInfo['deficit'] > 0 && $maxPeriodsPerDay === 1) {
       $maxPeriodsPerDay = 2;
   }
   ```
   Insert immediately after the `$maxPeriodsPerDay` assignment in the second pass loop.

3. **No changes required to `wouldCreateBackToBackPeriods()`**: The existing `$isLateWeekSlot`
   parameter already handles flexible back-to-back rules for Friday afternoon. The fix only
   addresses the daily cap that fires before the back-to-back check.

4. **No changes to unit-cap enforcement**: The hard stop
   `if ($currentSubjectUnits >= $subjectRequiredUnits) { continue; }` remains untouched and
   continues to prevent any over-assignment beyond the exact weekly unit requirement.

## Testing Strategy

### Validation Approach

Two-phase approach: first run exploratory tests on the unfixed code to confirm the root cause,
then verify the fix satisfies Property 1 (bug condition) and Property 2 (preservation).

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug on the UNFIXED code and confirm the
daily cap is the blocking condition.

**Test Plan**: Construct a minimal scheduling scenario — one section, one 5-unit subject, one
teacher available all week — where the first four periods are placed Monday–Thursday and the fifth
must land on Friday afternoon. Assert that the fifth period is assigned. Run on unfixed code to
observe the failure.

**Test Cases**:
1. **Friday afternoon deficit test**: Section with 1 subject (5 units), teacher available Mon–Fri
   all slots. Force first pass to assign Mon p2, Tue p2, Wed p2, Thu p2, then assert Fri p7 gets
   assigned. (Will fail on unfixed code — daily cap blocks it if Fri p2 was also assigned.)
2. **SKIP slot recovery test**: Same setup but mark Fri p2 as SKIP manually. Assert second pass
   fills Fri p2 with the subject. (Will fail on unfixed code when `usageToday >= 1`.)
3. **Multiple subjects, one with deficit**: Section with 3 subjects (5 units each). After first
   pass, one subject has only 4 periods. Assert second pass fills the gap on Friday afternoon.
4. **Edge case — already-met subject not over-assigned**: Subject with 5 units, all 5 assigned.
   Assert no 6th assignment occurs even after fix. (Must pass on both unfixed and fixed code.)

**Expected Counterexamples**:
- Fifth period of a 5-unit subject is never assigned; section ends with 4 periods for that subject.
- Possible causes: `maxPeriodsPerDay = 1` fires unconditionally; SKIP recovery loop has same cap.

### Fix Checking

**Goal**: Verify Property 1 — for all inputs where `isBugCondition` holds, the fixed scheduler
assigns the subject.

**Pseudocode:**
```
FOR ALL (subject, targetDay, targetSlot, usageToday) WHERE isBugCondition(...) DO
  result := runScheduler_fixed(section, subject, teacherAvailability)
  ASSERT subject.periodsAssigned = subject.requiredUnits
END FOR
```

### Preservation Checking

**Goal**: Verify Property 2 — for all inputs where `isBugCondition` does NOT hold, the fixed
scheduler produces the same result as the original.

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT runScheduler_original(input) = runScheduler_fixed(input)
END FOR
```

**Testing Approach**: Property-based testing is recommended because:
- It generates many random teacher/section/subject configurations automatically.
- It catches edge cases (e.g., subjects with 6 units, subjects with 0 usage today) that manual
  tests might miss.
- It provides strong guarantees that the relaxation only fires under the exact deficit condition.

**Test Cases**:
1. **No-deficit preservation**: Subject already has all required periods. Verify no additional
   assignment occurs after fix.
2. **Non-Friday-afternoon slot preservation**: Subject has deficit but target slot is Mon p3.
   Verify daily cap still enforces 1-per-day (fix should not affect this slot).
3. **6-unit subject preservation**: Subject with 6 units, `maxPeriodsPerDay = 2`. Verify behavior
   unchanged (fix only touches the `$maxPeriodsPerDay === 1` branch).
4. **Teacher unavailability preservation**: Teacher not available Friday afternoon. Verify slot
   remains unassigned even after fix (teacher check is independent of daily cap).

### Unit Tests

- Test first pass: 5-unit subject with deficit on Friday p7 gets assigned (fix applied).
- Test first pass: 5-unit subject with no deficit on Friday p7 does NOT get assigned.
- Test second pass: SKIP slot on Friday p8, subject has deficit — gets assigned after fix.
- Test second pass: SKIP slot on Monday p3, subject has deficit — gets assigned after fix.
- Test: subject with 6 units is unaffected by the fix (already allows 2/day).

### Property-Based Tests

- Generate random sections with 1–10 subjects (1–8 units each) and verify every subject's
  `periodsAssigned === requiredUnits` after the fixed scheduler runs.
- Generate random teacher availability patterns and verify no assignment violates teacher
  availability constraints.
- Generate scenarios where all subjects have met their requirements and verify no over-assignment
  occurs.

### Integration Tests

- Full auto-schedule run with a JHS section containing multiple 5-unit subjects; verify all
  subjects reach their exact unit count and Friday afternoon slots are utilized.
- Full auto-schedule run with an SHS section; verify Saturday slots are correctly used for SHS
  and Friday afternoon fix does not interfere.
- Regression run: compare schedule output before and after fix for sections where no subject has
  a Friday afternoon deficit; verify output is identical.
