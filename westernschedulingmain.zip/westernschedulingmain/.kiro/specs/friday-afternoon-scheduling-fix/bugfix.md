# Bugfix Requirements Document

## Introduction

The auto-scheduling algorithm in `api/auto_schedule.php` fails to fill Friday afternoon time slots for subjects with 5 units, even when the assigned teacher is available during those slots. The algorithm uses a sequential slot-filling strategy (Monday through Friday, slot p2 through p9) combined with a strict `maxPeriodsPerDay = 1` rule for subjects with ≤5 units. When earlier slots in the week are skipped due to teacher unavailability or back-to-back conflict prevention, the subject may exhaust its 5-period quota before reaching Friday afternoon slots — or, if Friday morning was also skipped, the SKIP marker blocks retry and the afternoon slots remain empty. This results in incomplete schedules where Friday afternoon periods are left unfilled despite teacher availability and remaining unit requirements.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a subject has exactly 5 units AND the teacher is available on Friday afternoon slots (p7, p8, p9) AND the subject still has unmet unit requirements THEN the system skips Friday afternoon slots and leaves them empty.

1.2 WHEN a slot is marked as SKIP during the first pass (because no teacher/subject could be assigned) AND the second pass attempts to fill it THEN the system still enforces `maxPeriodsPerDay = 1` for ≤5 unit subjects, preventing the subject from being placed even when it has a remaining deficit and the teacher is available.

1.3 WHEN the sequential slot scan reaches a Friday afternoon slot AND the subject already has 1 period assigned on Friday morning (p2–p6) THEN the system refuses to assign the subject to the afternoon slot even if the subject's total weekly unit count is still below its required 5 units.

### Expected Behavior (Correct)

2.1 WHEN a subject has exactly 5 units AND the teacher is available on Friday afternoon slots AND the subject still has unmet unit requirements THEN the system SHALL assign the subject to the available Friday afternoon slot to fulfill the unit requirement.

2.2 WHEN a slot is marked as SKIP AND the second pass processes it AND a subject still has a unit deficit AND the teacher is available THEN the system SHALL relax the `maxPeriodsPerDay` constraint to allow the subject to be placed in that slot, ensuring the weekly unit requirement is met.

2.3 WHEN the total periods assigned for a subject across the week is less than its required units AND no other slot is available to fulfill the requirement THEN the system SHALL allow a second period of that subject on the same day (including Friday) rather than leave the unit requirement unmet.

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a subject has 5 units AND all 5 periods have already been assigned across the week THEN the system SHALL CONTINUE TO prevent any additional assignments for that subject beyond its unit requirement.

3.2 WHEN a teacher is not available on a given day and slot THEN the system SHALL CONTINUE TO skip that slot for that teacher and not assign them.

3.3 WHEN a subject with ≤5 units already has 1 period assigned on a given day AND the subject's weekly unit requirement is already fully met THEN the system SHALL CONTINUE TO enforce the 1-period-per-day limit and not assign a second period on that day.

3.4 WHEN scheduling JHS sections THEN the system SHALL CONTINUE TO restrict assignments to Monday through Friday only, never assigning Saturday slots.

3.5 WHEN a subject would create 3 or more consecutive back-to-back periods on the same day THEN the system SHALL CONTINUE TO prevent that assignment to avoid excessive consecutive periods.
