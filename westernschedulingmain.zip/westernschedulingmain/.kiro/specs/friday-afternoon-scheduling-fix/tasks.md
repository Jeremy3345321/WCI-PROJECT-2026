# Implementation Plan

- [ ] 1. Write bug condition exploration test
  - **Property 1: Bug Condition** - Friday Afternoon Deficit Slot Not Filled
  - **CRITICAL**: This test MUST FAIL on unfixed code — failure confirms the bug exists
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior — it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate the daily cap unconditionally blocks Friday afternoon slots
  - **Scoped PBT Approach**: Scope the property to the concrete failing case — a 5-unit subject where Mon–Thu each get 1 period and the 5th must land on Friday p7/p8/p9
  - Construct a minimal scheduling scenario: 1 section, 1 subject with 5 units, 1 teacher available all week (Mon–Fri, all slots)
  - Force the first four periods onto Mon p2, Tue p2, Wed p2, Thu p2 (or simulate via `$subjectUsagePerDay` and `$subjectUsagePerWeek` state)
  - Assert that after the scheduler runs, the subject has exactly 5 periods assigned and at least one falls on Friday p7, p8, or p9
  - Run test on UNFIXED `api/auto_schedule.php`
  - **EXPECTED OUTCOME**: Test FAILS — subject ends the week with 4 periods; Friday afternoon slot is skipped because `maxPeriodsPerDay = 1` fires unconditionally even when `usageToday = 1` and `deficit = 1`
  - Document the counterexample: e.g., "Subject 'Mathematics' assigned 4/5 periods; Friday p7 skipped despite teacher availability and remaining deficit"
  - Also test the SKIP slot variant: mark Friday p2 as SKIP, assert second pass fills it when `usageToday >= 1` and deficit > 0 — this will also fail on unfixed code
  - Mark task complete when test is written, run, and failure is documented
  - _Requirements: 1.1, 1.2, 1.3_

- [ ] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** - Non-Deficit and Non-Buggy-Slot Behavior Unchanged
  - **IMPORTANT**: Follow observation-first methodology — run UNFIXED code with non-buggy inputs and record actual outputs before writing assertions
  - Observe: a 5-unit subject with all 5 periods already assigned receives no 6th assignment on unfixed code
  - Observe: a 5-unit subject with deficit on Monday p3 (not a Friday afternoon slot) is still capped at 1 period per day on unfixed code
  - Observe: a 6-unit subject with `maxPeriodsPerDay = 2` behaves identically on unfixed code
  - Observe: a teacher marked unavailable on Friday afternoon is never assigned there on unfixed code
  - Write property-based tests covering:
    - For all subjects where `deficit = 0`: no additional assignment occurs regardless of available slots (validates Requirement 3.1)
    - For all subjects with deficit on non-Friday-afternoon, non-SKIP slots: daily cap of 1 is still enforced (validates Requirement 3.3)
    - For all subjects with 6+ units: `maxPeriodsPerDay = 2` behavior is unchanged (validates Requirement 3.1)
    - For all teacher-unavailable slots: slot remains unassigned (validates Requirement 3.2)
    - For JHS sections: no Saturday assignments ever occur (validates Requirement 3.4)
    - For any subject that would create 3+ consecutive periods: assignment is blocked (validates Requirement 3.5)
  - Run all tests on UNFIXED code
  - **EXPECTED OUTCOME**: All preservation tests PASS on unfixed code (confirms baseline behavior to preserve)
  - Mark task complete when tests are written, run, and passing on unfixed code
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [-] 3. Fix for Friday afternoon and SKIP slot daily cap not relaxing when subject has a deficit

  - [x] 3.1 Implement first-pass deficit-aware relaxation (~line 620–630 in `api/auto_schedule.php`)
    - Locate the block that computes `$maxPeriodsPerDay` in the first pass (inside the `foreach ($subjectsNeedingPeriods as $subjInfo)` loop)
    - After the existing `if ($requiredUnits <= 5) { $maxPeriodsPerDay = 1; } else { $maxPeriodsPerDay = 2; }` assignment, insert:
      ```php
      // Relax daily cap for Friday afternoon slots when subject has a deficit
      $isLateWeekSlot = ($targetDay === 'Friday' && in_array($targetSlot, ['p7', 'p8', 'p9']));
      if ($isLateWeekSlot && $subjInfo['deficit'] > 0 && $maxPeriodsPerDay === 1) {
          $maxPeriodsPerDay = 2;
      }
      ```
    - Remove or merge the duplicate `$isLateWeekSlot` variable computed a few lines later (used for back-to-back rules) to avoid shadowing
    - The `if ($subjectUsageToday >= $maxPeriodsPerDay) { continue; }` guard that follows remains untouched
    - _Bug_Condition: isBugCondition where units ≤ 5, deficit > 0, usageToday >= 1, targetDay = 'Friday', targetSlot IN ['p7','p8','p9']_
    - _Expected_Behavior: subject is assigned to the Friday afternoon slot; periodsAssigned reaches requiredUnits_
    - _Preservation: subjects with deficit = 0 are unaffected; non-Friday-afternoon slots are unaffected; 6-unit subjects are unaffected_
    - _Requirements: 2.1, 2.3, 3.1, 3.2, 3.3, 3.5_

  - [x] 3.2 Implement second-pass deficit-aware relaxation (~line 960–970 in `api/auto_schedule.php`)
    - Locate the SKIP slot recovery loop (second pass) — search for the block that iterates over `$sectionSchedule` entries equal to `'SKIP'`
    - Find the `$maxPeriodsPerDay` assignment in that loop (same pattern: `if ($requiredUnits <= 5) { $maxPeriodsPerDay = 1; }`)
    - After that assignment, insert:
      ```php
      // In second pass: relax daily cap whenever subject has a deficit (SKIP recovery)
      if ($subjInfo['deficit'] > 0 && $maxPeriodsPerDay === 1) {
          $maxPeriodsPerDay = 2;
      }
      ```
    - The relaxation applies to any SKIP slot on any day (not just Friday), because SKIP recovery is already a last-resort path
    - The `if ($subjectUsageToday >= $maxPeriodsPerDay) { continue; }` guard that follows remains untouched
    - _Bug_Condition: isBugCondition where units ≤ 5, deficit > 0, usageToday >= 1, targetSlot IS SKIP_SLOT_
    - _Expected_Behavior: subject is assigned to the SKIP slot; periodsAssigned reaches requiredUnits_
    - _Preservation: subjects with deficit = 0 are unaffected; teacher availability check still gates every assignment_
    - _Requirements: 2.2, 2.3, 3.1, 3.2, 3.3_

  - [ ] 3.3 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** - Friday Afternoon Deficit Slot Not Filled
    - **IMPORTANT**: Re-run the SAME test from task 1 — do NOT write a new test
    - The test from task 1 encodes the expected behavior (subject reaches exactly 5 periods, Friday afternoon slot is used)
    - Run bug condition exploration test from step 1 against the FIXED code
    - **EXPECTED OUTCOME**: Test PASSES — subject is assigned all 5 periods; Friday p7/p8/p9 slot is filled; SKIP slot recovery also assigns correctly
    - _Requirements: 2.1, 2.2, 2.3_

  - [ ] 3.4 Verify preservation tests still pass
    - **Property 2: Preservation** - Non-Deficit and Non-Buggy-Slot Behavior Unchanged
    - **IMPORTANT**: Re-run the SAME tests from task 2 — do NOT write new tests
    - Run all preservation property tests from step 2 against the FIXED code
    - **EXPECTED OUTCOME**: All tests PASS — no regressions; subjects with no deficit are not over-assigned; non-Friday-afternoon daily caps are unchanged; teacher unavailability still blocks assignments; JHS Saturday restriction intact; 3+ consecutive period prevention intact

- [ ] 4. Checkpoint — Ensure all tests pass
  - Run the full test suite (exploration test + all preservation tests)
  - Confirm Property 1 passes: every subject where `isBugCondition` held now reaches its exact `requiredUnits`
  - Confirm Property 2 passes: no scheduling decision changed for inputs where `isBugCondition` was false
  - Optionally run a full end-to-end auto-schedule request against a real or seeded database and verify Friday afternoon slots are populated for 5-unit subjects
  - Ensure all tests pass; ask the user if questions arise
