# Design Document: Edit Teacher Modal Redesign

## Overview

The current edit teacher modal suffers from excessive vertical scrolling due to a single-column layout containing 6 major sections (Basic Information, Department & Grade Selection, Curriculum/Term/Semester filters, Subject Assignments table, and Availability schedule). This design proposes a tabbed interface to organize content into logical groups, reducing cognitive load and eliminating the need for scrolling through unrelated sections.

The redesign maintains all existing functionality while improving usability through better information architecture and progressive disclosure patterns.

## Architecture

```mermaid
graph TD
    A[Edit Teacher Modal] --> B[Modal Header]
    A --> C[Tab Navigation]
    A --> D[Tab Content Area]
    A --> E[Modal Footer]
    
    C --> C1[Basic Info Tab]
    C --> C2[Departments Tab]
    C --> C3[Subjects Tab]
    C --> C4[Schedule Tab]
    
    D --> D1[Basic Info Content]
    D --> D2[Departments Content]
    D --> D3[Subjects Content]
    D --> D4[Schedule Content]
    
    D2 --> D2A[Department Selection]
    D2 --> D2B[Grade Level Checkboxes]
    D2 --> D2C[Curriculum Filters]
    
    D3 --> D3A[Filter Controls]
    D3 --> D3B[Subjects Table]
    
    D4 --> D4A[Availability Grid]
    
    E --> E1[Cancel Button]
    E --> E2[Reset Button]
    E --> E3[Save Button]
```

## Components and Interfaces

### Component 1: Modal Container

**Purpose**: Main container for the edit teacher modal with tabbed interface

**Interface**:
```typescript
interface EditTeacherModal {
  teacherId: string
  currentTab: TabType
  formData: TeacherFormData
  
  open(teacherId: string): void
  close(): void
  switchTab(tab: TabType): void
  save(): Promise<void>
  reset(): void
}

type TabType = 'basic' | 'departments' | 'subjects' | 'schedule'
```

**Responsibilities**:
- Manage modal visibility and state
- Handle tab switching with validation
- Coordinate data flow between tabs
- Persist form data across tab switches

### Component 2: Tab Navigation

**Purpose**: Horizontal tab bar for switching between content sections

**Interface**:
```typescript
interface TabNavigation {
  tabs: Tab[]
  activeTab: TabType
  validationState: Record<TabType, boolean>
  
  renderTabs(): HTMLElement
  setActiveTab(tab: TabType): void
  updateValidationIndicator(tab: TabType, isValid: boolean): void
}

interface Tab {
  id: TabType
  label: string
  icon: string
  isValid: boolean
  isEnabled: boolean
}
```

**Responsibilities**:
- Display tab buttons with icons and labels
- Highlight active tab
- Show validation indicators (checkmarks, warnings)
- Enable/disable tabs based on dependencies

### Component 3: Basic Info Tab

**Purpose**: Capture teacher's name and employment type

**Interface**:
```typescript
interface BasicInfoTab {
  name: string
  employmentType: 'full-time' | 'part-time'
  
  validate(): boolean
  getData(): BasicInfoData
  setData(data: BasicInfoData): void
}

interface BasicInfoData {
  name: string
  employmentType: 'full-time' | 'part-time'
}
```

**Responsibilities**:
- Validate required fields (name)
- Provide clean, focused input form
- Minimal vertical space usage

### Component 4: Departments Tab

**Purpose**: Department selection, grade levels, and curriculum filters

**Interface**:
```typescript
interface DepartmentsTab {
  departments: DepartmentSelection
  jhsGrades: GradeSelection
  shsGrades: GradeSelection
  curriculum: 'new' | 'old'
  jhsTerm: string | null
  shsSemester: string | null
  strand: string | null
  electiveType: string | null
  electiveSubtype: string | null
  
  validate(): boolean
  getData(): DepartmentData
  setData(data: DepartmentData): void
  onDepartmentChange(): void
}

interface DepartmentSelection {
  jhs: boolean
  shs: boolean
}

interface GradeSelection {
  grade7?: boolean
  grade8?: boolean
  grade9?: boolean
  grade10?: boolean
  grade11?: boolean
  grade12?: boolean
}
```

**Responsibilities**:
- Manage department and grade level selection
- Show/hide grade checkboxes based on department
- Display curriculum filters (term, semester, strand, elective)
- Trigger subject filtering when selections change

### Component 5: Subjects Tab

**Purpose**: Subject assignment with filtering and search

**Interface**:
```typescript
interface SubjectsTab {
  subjects: Subject[]
  selectedSubjects: string[]
  filters: SubjectFilters
  
  loadSubjects(): Promise<void>
  filterSubjects(): Subject[]
  toggleSubject(subjectName: string): void
  getData(): string[]
  setData(subjects: string[]): void
}

interface Subject {
  name: string
  type: 'jhs' | 'shs'
  grade: string
  semester?: string
  category: 'core' | 'applied' | 'major' | 'minor'
  strand?: string
  electiveType?: string
}

interface SubjectFilters {
  jhsTerm: string | null
  shsSemester: string | null
  strand: string | null
  electiveType: string | null
}
```

**Responsibilities**:
- Load subjects from API based on curriculum
- Filter subjects by department, grade, term, semester, strand
- Display subjects in categorized table (Core vs Applied)
- Show assignment status (assigned to you, assigned to others, not assigned)
- Update assignment status on checkbox change

### Component 6: Schedule Tab

**Purpose**: Teacher availability selection

**Interface**:
```typescript
interface ScheduleTab {
  availability: AvailabilityData
  
  validate(): boolean
  getData(): AvailabilityData
  setData(data: AvailabilityData): void
}

interface AvailabilityData {
  [day: string]: {
    [period: string]: boolean
  }
}
```

**Responsibilities**:
- Display availability checkboxes in grid format
- Allow selection of available time slots
- Validate at least one slot is selected

## Data Models

### Model 1: TeacherFormData

```typescript
interface TeacherFormData {
  id: string
  name: string
  employmentType: 'full-time' | 'part-time'
  departments: {
    jhs: boolean
    shs: boolean
    grade11?: boolean
    grade12?: boolean
  }
  jhsGrades: {
    grade7: boolean
    grade8: boolean
    grade9: boolean
    grade10: boolean
  }
  curriculum: 'new' | 'old'
  jhsTerm: string | null
  shsSemester: string | null
  strand: string | null
  electiveType: string | null
  electiveSubtype: string | null
  subjects: string[]
  availability: AvailabilityData
}
```

**Validation Rules**:
- `name` must be non-empty string
- At least one department must be selected
- If JHS selected, at least one JHS grade must be selected
- If SHS selected, at least one SHS grade (11 or 12) must be selected
- At least one subject must be assigned
- At least one availability slot must be selected

### Model 2: TabState

```typescript
interface TabState {
  activeTab: TabType
  visitedTabs: Set<TabType>
  validationStatus: Record<TabType, ValidationStatus>
  isDirty: boolean
}

interface ValidationStatus {
  isValid: boolean
  errors: string[]
}
```

## Sequence Diagrams

### Opening Edit Teacher Modal

```mermaid
sequenceDiagram
    participant U as User
    participant UI as UI Layer
    participant M as Modal Component
    participant API as API Layer
    participant Cache as Teachers Cache
    
    U->>UI: Click "Edit" on teacher card
    UI->>M: openEditTeacher(teacherId)
    M->>Cache: Find teacher by ID
    Cache-->>M: Teacher data
    M->>M: Initialize modal DOM (if first time)
    M->>M: Set form values from teacher data
    M->>M: Set active tab to "basic"
    M->>API: Load subjects for curriculum
    API-->>M: Subjects data
    M->>M: Populate subjects table
    M->>UI: Show modal
    UI-->>U: Display modal with Basic Info tab
```

### Switching Tabs

```mermaid
sequenceDiagram
    participant U as User
    participant Nav as Tab Navigation
    participant M as Modal Component
    participant Tab as Tab Content
    
    U->>Nav: Click "Departments" tab
    Nav->>M: switchTab('departments')
    M->>M: Validate current tab
    alt Current tab invalid
        M->>U: Show validation errors
    else Current tab valid
        M->>M: Save current tab data
        M->>M: Set activeTab = 'departments'
        M->>Nav: Update active indicator
        M->>Tab: Load departments tab content
        Tab-->>U: Display departments form
    end
```

### Saving Teacher Changes

```mermaid
sequenceDiagram
    participant U as User
    participant M as Modal Component
    participant V as Validator
    participant API as API Layer
    participant Cache as Teachers Cache
    participant UI as UI Layer
    
    U->>M: Click "Save Changes"
    M->>M: Collect data from all tabs
    M->>V: Validate all form data
    alt Validation fails
        V-->>M: Validation errors
        M->>U: Show error messages
    else Validation passes
        V-->>M: Valid data
        M->>API: PUT /api/teachers.php
        API-->>M: Success response
        M->>Cache: Update teacher in cache
        M->>UI: Refresh teacher card
        M->>M: Close modal
        M->>U: Show success toast
    end
```

## Tab Layout Specifications

### Tab 1: Basic Info

**Layout**: Single column, centered, minimal height

**Content**:
- Teacher name input (full width)
- Employment type radio buttons (horizontal)

**Estimated Height**: 200px

### Tab 2: Departments

**Layout**: Two-column grid for department cards, filters below

**Content**:
- Department cards (JHS, SHS) with nested grade checkboxes
- Curriculum radio buttons (New/Old)
- Conditional filters (JHS Term, SHS Semester, Strand, Elective Type)

**Estimated Height**: 400-500px

### Tab 3: Subjects

**Layout**: Filter controls at top, table below

**Content**:
- Active filters display (read-only, inherited from Departments tab)
- Subjects table with columns: Subject Name, Grade Level, Assignment Status
- Categorized rows (Core Subjects, Applied & Specialized)

**Estimated Height**: 500-600px (with internal scrolling for table)

### Tab 4: Schedule

**Layout**: Grid of checkboxes (days × periods)

**Content**:
- Availability grid (Monday-Saturday, 8 periods + breaks)

**Estimated Height**: 400-500px

## User Interaction Flows

### Flow 1: Edit Teacher Basic Information

1. User clicks "Edit" button on teacher card
2. Modal opens with "Basic Info" tab active
3. User modifies name or employment type
4. User clicks "Departments" tab
5. System validates Basic Info tab (name required)
6. System switches to Departments tab

### Flow 2: Change Department and Assign Subjects

1. User is on "Departments" tab
2. User checks "Junior High School" checkbox
3. System shows JHS grade checkboxes (7-10)
4. User selects Grade 7 and Grade 8
5. User selects curriculum and term filters
6. User clicks "Subjects" tab
7. System loads and filters subjects based on department/grade/term
8. User checks subjects to assign
9. User clicks "Save Changes"
10. System validates all tabs and saves

### Flow 3: Update Availability Schedule

1. User clicks "Schedule" tab
2. System displays availability grid
3. User checks/unchecks time slots
4. User clicks "Save Changes"
5. System validates at least one slot selected
6. System saves changes and closes modal

## Correctness Properties

### Property 1: Tab State Consistency

**Statement**: For all tab switches, the form data from the previous tab must be preserved and accessible when returning to that tab.

**Formal Expression**:
```
∀ tab₁, tab₂ ∈ TabType, data ∈ FormData:
  switchTab(tab₁ → tab₂) ∧ switchTab(tab₂ → tab₁) ⟹ 
  getData(tab₁) = data_before_switch
```

### Property 2: Department-Subject Consistency

**Statement**: The subjects displayed in the Subjects tab must always match the departments and grades selected in the Departments tab.

**Formal Expression**:
```
∀ teacher ∈ Teachers, subjects ∈ SubjectList:
  displayedSubjects(teacher) = 
    filter(subjects, s ⟹ 
      (s.type = 'jhs' ∧ teacher.departments.jhs) ∨
      (s.type = 'shs' ∧ teacher.departments.shs))
```

### Property 3: Validation Before Save

**Statement**: The save operation must only proceed if all tabs pass validation.

**Formal Expression**:
```
∀ tabs ∈ TabType[]:
  canSave() ⟺ ∀ tab ∈ tabs: validate(tab) = true
```

### Property 4: Required Field Validation

**Statement**: Teacher name must be non-empty, at least one department must be selected, and at least one subject must be assigned.

**Formal Expression**:
```
∀ teacher ∈ TeacherFormData:
  isValid(teacher) ⟺ 
    teacher.name ≠ "" ∧
    (teacher.departments.jhs ∨ teacher.departments.shs) ∧
    |teacher.subjects| ≥ 1 ∧
    |teacher.availability| ≥ 1
```

### Property 5: Grade Selection Dependency

**Statement**: If a department is unchecked, all its associated grade checkboxes must be unchecked and hidden.

**Formal Expression**:
```
∀ teacher ∈ TeacherFormData:
  ¬teacher.departments.jhs ⟹ 
    ∀ g ∈ {7,8,9,10}: teacher.jhsGrades[g] = false ∧
  ¬teacher.departments.shs ⟹
    teacher.departments.grade11 = false ∧ 
    teacher.departments.grade12 = false
```

## Error Handling

### Error Scenario 1: No Department Selected

**Condition**: User attempts to switch to Subjects tab without selecting any department
**Response**: Show inline error message "Please select at least one department"
**Recovery**: Prevent tab switch, keep user on Departments tab

### Error Scenario 2: Empty Teacher Name

**Condition**: User attempts to save with empty name field
**Response**: Switch to Basic Info tab, highlight name field, show error "Teacher name is required"
**Recovery**: User fills in name and saves again

### Error Scenario 3: No Subjects Assigned

**Condition**: User attempts to save without selecting any subjects
**Response**: Switch to Subjects tab, show error "Please assign at least one subject"
**Recovery**: User selects subjects and saves again

### Error Scenario 4: No Availability Selected

**Condition**: User attempts to save without selecting any availability slots
**Response**: Switch to Schedule tab, show error "Please select at least one available time slot"
**Recovery**: User selects time slots and saves again

### Error Scenario 5: API Save Failure

**Condition**: Server returns error during save operation
**Response**: Show error toast with message from server
**Recovery**: Keep modal open with data intact, allow user to retry

## Testing Strategy

### Unit Testing Approach

**Test Coverage**:
- Tab switching logic (state preservation, validation)
- Form data collection from each tab
- Validation rules for each field
- Department-grade dependency logic
- Subject filtering based on department/grade/term/semester

**Key Test Cases**:
1. Test tab switching preserves form data
2. Test validation prevents invalid tab switches
3. Test department selection shows/hides grade checkboxes
4. Test subject filtering matches department selection
5. Test save button validates all tabs before submission

### Property-Based Testing Approach

**Property Test Library**: fast-check (JavaScript)

**Properties to Test**:
1. **Tab State Preservation**: Switching between any two tabs and back preserves data
2. **Subject Filtering Consistency**: Filtered subjects always match selected departments
3. **Validation Completeness**: Invalid data always fails validation
4. **Grade Dependency**: Unchecking department always unchecks associated grades

**Example Property Test**:
```javascript
fc.assert(
  fc.property(
    fc.record({
      jhs: fc.boolean(),
      shs: fc.boolean(),
      grade7: fc.boolean(),
      grade8: fc.boolean(),
      grade9: fc.boolean(),
      grade10: fc.boolean()
    }),
    (deptData) => {
      const teacher = { departments: deptData };
      if (!deptData.jhs) {
        return !deptData.grade7 && !deptData.grade8 && 
               !deptData.grade9 && !deptData.grade10;
      }
      return true;
    }
  )
);
```

### Integration Testing Approach

**Test Scenarios**:
1. Open modal → modify all tabs → save → verify API call and cache update
2. Open modal → switch tabs → verify data persistence
3. Open modal → invalid data → save → verify error handling
4. Open modal → change department → verify subject list updates

## Performance Considerations

**Optimization Strategies**:
- Lazy load subjects only when Subjects tab is first accessed
- Cache subjects data to avoid redundant API calls
- Use event delegation for checkbox event handlers
- Debounce filter changes to reduce re-renders
- Virtualize subjects table if list exceeds 100 items

**Performance Targets**:
- Modal open time: < 300ms
- Tab switch time: < 100ms
- Subject filtering: < 50ms
- Save operation: < 500ms

## Security Considerations

**Security Measures**:
- Validate all input on client and server side
- Sanitize teacher name to prevent XSS
- Verify teacher ID exists before allowing edits
- Check user permissions before allowing save
- Use CSRF tokens for save requests

**Threat Mitigation**:
- SQL Injection: Use parameterized queries in API
- XSS: Escape all user input before rendering
- CSRF: Include token in save request
- Unauthorized Access: Verify session before allowing edits

## Dependencies

**External Libraries**:
- None (vanilla JavaScript)

**Internal Dependencies**:
- `teachersCache`: Global cache of teacher data
- `api/teachers.php`: Teacher CRUD API endpoint
- `api/subjects.php`: Subjects list API endpoint
- CSS variables from `style.css` for theming

**Browser APIs**:
- Fetch API for HTTP requests
- LocalStorage (optional) for draft persistence
- DOM APIs for modal rendering and event handling
