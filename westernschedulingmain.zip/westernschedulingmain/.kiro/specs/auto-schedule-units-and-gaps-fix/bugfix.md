# Bugfix Requirements Document

## Introduction

The auto-schedule generation system in `api/auto_schedule.php` has three related bugs affecting schedule correctness. First, subjects are not placed exactly the number of times their assigned unit count requires — some subjects appear too few or too many times per week. Second, the generated schedule contains empty/free slots between scheduled subjects within a day instead of packing all subjects consecutively from the first period (gaps should only appear at the end of the day). Third, the same subject can be placed more than once on the same day, violating the one-subject-per-day constraint that is required when distributing units across the week.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a subject has N units assigned and the auto-schedule is generated THEN the system places that subject fewer or more than N times per week instead of exactly N times

1.2 WHEN subjects are assigned to a section's day during auto-schedule generation THEN the system leaves empty slots between scheduled subjects within the same day instead of packing them consecutively from the first available period

1.3 WHEN the day-distribution plan assigns a subject to a day and a teacher is unavailable at the initially chosen slot THEN the system skips to a later slot, potentially leaving a gap before the subject and breaking the no-gap packing rule

1.4 WHEN the auto-schedule algorithm distributes subject units across days THEN the system allows the same subject to be placed on the same day more than once, violating the one-occurrence-per-day constraint

### Expected Behavior (Correct)

2.1 WHEN a subject has N units assigned and the auto-schedule is generated THEN the system SHALL place that subject exactly N times across the week, no more and no less

2.2 WHEN subjects are assigned to a section's day during auto-schedule generation THEN the system SHALL place all subjects in consecutive slots starting from the first available period, with no empty slots between any two scheduled subjects (free time SHALL only appear at the end of the day after all subjects are placed)

2.3 WHEN a teacher is unavailable at a given slot for a subject THEN the system SHALL try the next available teacher for that slot rather than skipping to a later slot, so that the no-gap packing order is preserved

2.4 WHEN the auto-schedule algorithm distributes subject units across days THEN the system SHALL ensure each subject appears at most once per day, selecting N distinct days for a subject with N units

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a subject has 1 unit assigned THEN the system SHALL CONTINUE TO place that subject exactly once per week on a single day

3.2 WHEN teacher availability restrictions are configured THEN the system SHALL CONTINUE TO respect those restrictions and not assign a teacher to a slot they are marked unavailable for

3.3 WHEN a section has no available teacher for a subject on any slot of any day THEN the system SHALL CONTINUE TO record a failed assignment and skip that subject without crashing

3.4 WHEN PRELIMINARIES are scheduled at p1 for JHS sections THEN the system SHALL CONTINUE TO assign them to the advisory teacher on Monday through Friday without being affected by the subject-packing changes

3.5 WHEN the recovery pass runs to fill subjects that missed their planned day THEN the system SHALL CONTINUE TO enforce the one-subject-per-day rule and the no-gap packing order during recovery placement

3.6 WHEN a section's total required periods exceed the available slots in the week THEN the system SHALL CONTINUE TO cap placement at the available slot count without overflowing into non-existent periods
