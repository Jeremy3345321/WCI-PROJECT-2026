# Auto-Schedule Units and Gaps Fix - Bugfix Design

## Overview

The auto-schedule generation system has three interrelated bugs that violate core scheduling constraints: (1) subjects are not placed exactly N times per week when they have N units assigned, (2) empty slots appear between scheduled subjects within a day instead of packing subjects consecutively from the first period, and (3) the same subject can appear multiple times on the same day, violating the one-occurrence-per-day distribution rule.

The fix strategy involves refining the existing algorithm (starting around line 560 in `api/auto_schedule.php`) to enforce strict unit compliance, gap-free sequential packing, and same-day duplicate prevention. The algorithm already attempts a day-distribution approach but has flaws in teacher availability handling, slot selection logic, and recovery pass behavior that cause these three bugs to manifest.

## Glossary

- **Bug_Condition (C)**: The condition that triggers any of the three bugs - when unit counts are violated, gaps appear within a day, or same-day duplicates occur
- **Property (P)**: The desired behavior - subjects appear exactly N times per week, all subjects pack consecutively from the first period with no intra-day gaps, and each subject appears at most once per day
- **Preservation**: Existing behaviors that must remain unchanged - single-unit subjects work correctly, teacher availability is respected, failed assignments are logged, PRELIMINARIES scheduling is unaffected
- **Unit Count**: The number of times a subject should appear per week (stored in `subjects.units` column)
- **Day Plan**: The distribution strategy that assigns each subject's N units to N distinct days before slot assignment
- **Sequential Packing**: The constraint that all subjects on a day must occupy consecutive slots starting from the first available period (p2 for most cases, p1 for PRELIMINARIES)
- **Intra-day Gap**: An empty slot that appears between two scheduled subjects on the same day (violates sequential packing)
- **Same-day Duplicate**: When the same subject is scheduled more than once on the same day (violates one-per-day distribution)
- **Recovery Pass**: The algorithm phase (Step 3) that places subjects that missed their planned day due to teacher unavailability

## Bug Details

### Bug Condition

The bugs manifest in three related scenarios within the auto-schedule generation process:

**Bug 1 - Unit Count Violations**: When a subject has N units assigned and the auto-schedule runs, the system places that subject fewer or more than N times per week. This occurs because the recovery pass (Step 3) may fail to place all deficit units when teachers are unavailable, or the day-distribution logic may incorrectly allow multiple placements on the same day.

**Bug 2 - Intra-day Gaps**: When subjects are assigned to a section's day, the system leaves empty slots between scheduled subjects instead of packing them consecutively from the first available period. This happens when a teacher is unavailable at the initially chosen slot and the algorithm skips to a later slot, leaving a gap before the subject.

**Bug 3 - Same-day Duplicates**: When the day-distribution plan assigns a subject to a day and the recovery pass runs, the system may place the same subject on a day where it was already scheduled, violating the one-occurrence-per-day constraint. This occurs because the recovery pass doesn't strictly enforce the same-day check or the initial day plan allows duplicates.

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type ScheduleGenerationResult
  OUTPUT: boolean
  
  // Bug 1: Unit count violation
  FOR EACH section IN input.sections DO
    FOR EACH subject IN section.subjects DO
      actualCount := countOccurrences(input.schedule, section.id, subject.name)
      IF actualCount != subject.units THEN
        RETURN true
      END IF
    END FOR
  END FOR
  
  // Bug 2: Intra-day gap
  FOR EACH section IN input.sections DO
    FOR EACH day IN section.scheduledDays DO
      slots := getScheduledSlots(input.schedule, section.id, day)
      IF hasGapBetweenSlots(slots) THEN
        RETURN true
      END IF
    END FOR
  END FOR
  
  // Bug 3: Same-day duplicate
  FOR EACH section IN input.sections DO
    FOR EACH day IN section.scheduledDays DO
      subjects := getSubjectsOnDay(input.schedule, section.id, day)
      IF hasDuplicates(subjects) THEN
        RETURN true
      END IF
    END FOR
  END FOR
  
  RETURN false
END FUNCTION

FUNCTION hasGapBetweenSlots(slots)
  // slots is array of slot IDs like ['p2', 'p3', 'p5', 'p6']
  // Gap exists if any slot number is missing between min and max
  IF length(slots) <= 1 THEN RETURN false
  slotNumbers := extractNumbers(slots) // [2, 3, 5, 6]
  minSlot := min(slotNumbers)
  maxSlot := max(slotNumbers)
  expectedCount := maxSlot - minSlot + 1
  RETURN length(slots) < expectedCount
END FUNCTION
```

### Examples

**Bug 1 - Unit Count Violations:**
- Subject "Mathematics" has 5 units assigned, but appears only 4 times in the generated schedule (deficit of 1)
- Subject "English" has 3 units assigned, but appears 4 times in the generated schedule (excess of 1)
- Subject "Science" has 4 units assigned, but appears 0 times because no teacher was available on any planned day

**Bug 2 - Intra-day Gaps:**
- Monday schedule for Section 7-A: p2=Math, p3=English, p4=(empty), p5=Science, p6=Filipino
  - Gap at p4 violates sequential packing (should be: p2=Math, p3=English, p4=Science, p5=Filipino, p6=(empty))
- Tuesday schedule for Section 11-STEM: p2=Calculus, p3=(empty), p4=(empty), p5=Physics
  - Gaps at p3 and p4 violate sequential packing (should be: p2=Calculus, p3=Physics, p4=(empty), p5=(empty))

**Bug 3 - Same-day Duplicates:**
- Wednesday schedule for Section 8-B: p2=Filipino, p3=Math, p4=English, p5=Filipino
  - Filipino appears twice on the same day (should appear on two different days)
- Thursday schedule for Section 12-ABM: p2=Business Math, p3=Accounting, p4=Business Math
  - Business Math appears twice on the same day (should appear on two different days)

**Edge Cases:**
- Subject with 1 unit should appear exactly once per week on one day (already works correctly)
- Subject with 6 units in a 5-day week (JHS) cannot be scheduled without same-day duplicates (should fail gracefully)
- All teachers unavailable for a subject on all days should result in 0 placements and a logged failed assignment

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- Single-unit subjects (N=1) must continue to be placed exactly once per week on a single day
- Teacher availability restrictions must continue to be strictly respected (no assignments to unavailable slots)
- Section availability restrictions must continue to be strictly respected
- Failed assignments must continue to be logged when no teacher is available for a subject
- PRELIMINARIES scheduling at p1 for JHS sections must continue to work correctly with advisory teachers
- The recovery pass must continue to attempt placement of subjects that missed their planned day
- The system must continue to cap placement at available slot count when total required periods exceed available slots

**Scope:**
All scheduling behaviors that do NOT involve the three bug conditions should be completely unaffected by this fix. This includes:
- Teacher load calculation and tracking (periods assigned per teacher)
- Advisory teacher assignment for PRELIMINARIES
- Subject filtering by grade, term, semester, and strand
- Department and grade-level eligibility checks for teachers
- Units compliance reporting in the API response
- Failed assignment tracking and reporting

## Hypothesized Root Cause

Based on the bug description and code analysis, the most likely issues are:

1. **Incomplete Recovery Pass Logic**: The recovery pass (Step 3, lines 640-670) attempts to place subjects with unit deficits but may not iterate through all available days or may stop prematurely when a teacher is unavailable, leaving some units unplaced. The loop structure `foreach ($availableDays as $day)` with `if ($deficit <= 0) break;` may exit too early if the first few days have no available teachers.

2. **Slot Selection Skipping Creates Gaps**: In Step 2 (lines 620-638), when a teacher is unavailable at the initially chosen slot (`$assignedSlot`), the algorithm tries later slots on the same day. However, this creates a gap because the `$slotIndex` advances past the unavailable slot, leaving it empty. The correct behavior should be to try a different teacher at the same slot rather than skipping to a later slot.

3. **Same-day Check Not Enforced in Recovery Pass**: The recovery pass checks `if (isset($subjectUsagePerDay[$sectionId][$day][$subjectName]) && $subjectUsagePerDay[$sectionId][$day][$subjectName] > 0) continue;` to skip days where the subject is already placed, but this check may not be working correctly or may be bypassed in certain code paths, allowing same-day duplicates.

4. **Day Plan Distribution Allows Duplicates**: The day-distribution logic (Step 1, lines 600-615) uses `asort($dayLoads)` and `array_slice` to pick the N days with fewest subjects, but if N exceeds the number of available days (e.g., 6 units in a 5-day JHS week), the logic may assign the same day multiple times to the `$daysToUse` array, causing same-day duplicates.

5. **Slot Index Not Reset Between Subjects**: In Step 2, the `$slotIndex` variable tracks the current position in `$availableSlots` and increments as subjects are placed. However, when a subject cannot be placed (no eligible teacher), the code attempts to restore the index with `$slotIndex = $savedIndex;`, but this restoration may not work correctly in all cases, causing subsequent subjects to skip slots and create gaps.

## Correctness Properties

Property 1: Bug Condition - Exact Unit Count Placement

_For any_ subject with N units assigned to a section, the fixed auto-schedule algorithm SHALL place that subject exactly N times across the week in the generated schedule, with no deficit (fewer than N) and no excess (more than N), unless no teacher is available on any day (in which case 0 placements with a logged failed assignment is acceptable).

**Validates: Requirements 2.1**

Property 2: Bug Condition - Sequential Packing Without Gaps

_For any_ section and day in the generated schedule, the fixed auto-schedule algorithm SHALL place all scheduled subjects in consecutive slots starting from the first available period (p2 for regular subjects, p1 for PRELIMINARIES), with no empty slots between any two scheduled subjects. Free time (empty slots) SHALL only appear at the end of the day after all subjects for that day are placed.

**Validates: Requirements 2.2, 2.3**

Property 3: Bug Condition - One Subject Per Day

_For any_ subject and section in the generated schedule, the fixed auto-schedule algorithm SHALL ensure that each subject appears at most once per day. When distributing N units of a subject across the week, the algorithm SHALL select N distinct days, never placing the same subject twice on the same day.

**Validates: Requirements 2.4**

Property 4: Preservation - Single-Unit Subject Behavior

_For any_ subject with 1 unit assigned, the fixed auto-schedule algorithm SHALL produce exactly the same placement behavior as the original algorithm, placing the subject exactly once per week on a single day.

**Validates: Requirements 3.1**

Property 5: Preservation - Teacher Availability Respect

_For any_ teacher with availability restrictions configured, the fixed auto-schedule algorithm SHALL produce exactly the same availability-checking behavior as the original algorithm, never assigning the teacher to a slot they are marked unavailable for.

**Validates: Requirements 3.2**

Property 6: Preservation - Failed Assignment Logging

_For any_ subject that cannot be scheduled due to lack of available teachers, the fixed auto-schedule algorithm SHALL produce exactly the same failed assignment logging behavior as the original algorithm, recording the failure without crashing.

**Validates: Requirements 3.3**

Property 7: Preservation - PRELIMINARIES Scheduling

_For any_ JHS section with an advisory teacher, the fixed auto-schedule algorithm SHALL produce exactly the same PRELIMINARIES scheduling behavior as the original algorithm, assigning PRELIMINARIES at p1 on Monday through Friday to the advisory teacher.

**Validates: Requirements 3.4**

## Fix Implementation

### Changes Required

Assuming our root cause analysis is correct:

**File**: `api/auto_schedule.php`

**Function**: Main scheduling algorithm (lines 560-680)

**Specific Changes**:

1. **Fix Slot Selection to Prevent Gaps (Bug 2)**:
   - In Step 2 (around line 620-638), when `$eligible` is empty (no teacher available at current slot), instead of trying later slots on the same day, try different teachers or mark the slot as failed
   - Change the fallback logic from "try next slot on this day" to "try next teacher at same slot" or "skip this subject and let recovery pass handle it"
   - Remove or fix the `$slotIndex` advancement that creates gaps when a teacher is unavailable
   - Ensure `$slotIndex` always points to the next consecutive slot, never skipping

2. **Enforce Same-day Check in Day Plan (Bug 3)**:
   - In Step 1 (around line 600-615), add validation to ensure `$daysToUse` array contains only unique days
   - If a subject has more units than available days (e.g., 6 units in 5-day week), cap the day plan at the number of available days and log a warning
   - Add explicit check: `$daysToUse = array_unique($daysToUse);` after `array_slice`

3. **Strengthen Recovery Pass Same-day Check (Bug 3)**:
   - In Step 3 (around line 640-670), ensure the same-day check `if (isset($subjectUsagePerDay[$sectionId][$day][$subjectName]) && $subjectUsagePerDay[$sectionId][$day][$subjectName] > 0) continue;` is always executed before attempting placement
   - Add explicit validation after placement to verify no same-day duplicate was created
   - If same-day duplicate is detected, roll back the placement and continue to next day

4. **Improve Recovery Pass Iteration (Bug 1)**:
   - In Step 3, change the loop structure to iterate through all available days for each unit deficit, not just until the first successful placement
   - Replace `foreach ($availableDays as $day) { if ($deficit <= 0) break; ... }` with a more robust structure that tries all days before giving up
   - Add a maximum attempts counter to prevent infinite loops if no teacher is available on any day

5. **Add Sequential Packing Validation (Bug 2)**:
   - After Step 2 and Step 3, add a validation pass that checks each day's schedule for gaps
   - If gaps are detected, attempt to compact the schedule by moving subjects to earlier slots
   - This is a safety net to catch any gaps that slip through the main algorithm

6. **Add Unit Count Validation (Bug 1)**:
   - After Step 3, add a validation pass that checks each subject's actual placement count against its required unit count
   - If discrepancies are found, log detailed information about which subjects are missing units and why (e.g., no available teachers)
   - This helps with debugging and provides better error messages to users

### Pseudocode for Key Changes

**Change 1 - Fix Slot Selection (Step 2):**
```
// Current (buggy) logic:
if (empty($eligible)) {
    // Try next slots on this day (creates gaps)
    while ($slotIndex < count($availableSlots)) {
        $slot = $availableSlots[$slotIndex];
        $slotIndex++;
        // ... try this slot
    }
}

// Fixed logic:
if (empty($eligible)) {
    // Don't skip to later slots - let recovery pass handle this subject
    // Restore slot index so next subject can use this slot
    $slotIndex = $savedIndex;
    continue; // Skip this subject, move to next subject in day plan
}
```

**Change 2 - Enforce Unique Days (Step 1):**
```
// After picking days for a subject:
$daysToUse = array_slice(array_keys($dayLoads), 0, $units);

// Add uniqueness check:
$daysToUse = array_unique($daysToUse);
if (count($daysToUse) < $units) {
    // Subject has more units than available days - log warning
    $failedAssignments[] = [
        'section' => $sectionId,
        'subject' => $subjectName,
        'reason' => "Subject requires $units units but only " . count($daysToUse) . " days available"
    ];
    // Cap units to available days
    $units = count($daysToUse);
}
```

**Change 3 - Strengthen Recovery Pass (Step 3):**
```
foreach ($availableDays as $day) {
    if ($deficit <= 0) break;
    
    // STRICT same-day check BEFORE attempting placement
    if (isset($subjectUsagePerDay[$sectionId][$day][$subjectName]) 
        && $subjectUsagePerDay[$sectionId][$day][$subjectName] > 0) {
        continue; // Subject already on this day - skip
    }
    
    // Find next free slot on this day
    foreach ($availableSlots as $slot) {
        // ... attempt placement ...
        
        // VALIDATE no same-day duplicate was created
        if (isset($subjectUsagePerDay[$sectionId][$day][$subjectName]) 
            && $subjectUsagePerDay[$sectionId][$day][$subjectName] > 1) {
            // Rollback - same-day duplicate detected
            unset($schedule[$teacher['id']][$day][$slot]);
            unset($sectionSchedule[$sectionId][$day][$slot]);
            $teacherPeriodCount[$teacher['id']]--;
            $subjectUsagePerDay[$sectionId][$day][$subjectName]--;
            $subjectUsagePerWeek[$sectionId][$subjectName]--;
            continue; // Try next slot
        }
        
        $deficit--;
        break; // One slot per day per subject
    }
}
```

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the three bugs on unfixed code, then verify the fix works correctly and preserves existing behavior. Testing will use a combination of unit tests (for specific scenarios), property-based tests (for broad input coverage), and integration tests (for full workflow validation).

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the three bugs BEFORE implementing the fix. Confirm or refute the root cause analysis. If we refute, we will need to re-hypothesize.

**Test Plan**: Write tests that generate schedules with various subject unit counts, teacher availability patterns, and section configurations. Run these tests on the UNFIXED code to observe failures and understand the root causes. Specifically test scenarios that are likely to trigger each bug.

**Test Cases**:

1. **Unit Count Violation Test - High Unit Subject**: Create a section with a subject that has 5 units and multiple available teachers. Generate schedule and verify the subject appears exactly 5 times. (will fail on unfixed code - likely shows deficit)

2. **Unit Count Violation Test - Multiple Subjects**: Create a section with 5 subjects each having 3 units. Generate schedule and verify each subject appears exactly 3 times. (will fail on unfixed code - likely shows mixed deficits and excesses)

3. **Intra-day Gap Test - Teacher Unavailability**: Create a section with 4 subjects on Monday, where the teacher for the 2nd subject is unavailable at p3 but available at p5. Generate schedule and verify no gap exists at p3. (will fail on unfixed code - likely shows gap at p3)

4. **Intra-day Gap Test - Multiple Days**: Create a section with subjects scheduled across Monday-Friday. Generate schedule and verify no gaps exist on any day. (will fail on unfixed code - likely shows gaps on multiple days)

5. **Same-day Duplicate Test - Recovery Pass**: Create a section with a subject that has 3 units, where the teacher is unavailable on 2 of the 3 planned days. Generate schedule and verify the subject does not appear twice on the same day during recovery. (will fail on unfixed code - likely shows same-day duplicate)

6. **Same-day Duplicate Test - Excessive Units**: Create a JHS section (5-day week) with a subject that has 6 units. Generate schedule and verify the subject does not appear twice on any day. (will fail on unfixed code - likely shows same-day duplicates)

**Expected Counterexamples**:
- Subjects with unit counts not matching actual placements (e.g., 5 units required but only 4 placed)
- Days with gaps between scheduled subjects (e.g., p2=Math, p3=(empty), p4=English)
- Days with same subject appearing multiple times (e.g., p2=Filipino, p5=Filipino)
- Possible causes: slot index advancement creating gaps, recovery pass not iterating all days, same-day check not enforced

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
FOR ALL scheduleInput WHERE isBugCondition(scheduleInput) DO
  result := autoSchedule_fixed(scheduleInput)
  ASSERT expectedBehavior(result)
END FOR

FUNCTION expectedBehavior(result)
  // Check Property 1: Exact unit counts
  FOR EACH section IN result.sections DO
    FOR EACH subject IN section.subjects DO
      actualCount := countOccurrences(result.schedule, section.id, subject.name)
      ASSERT actualCount == subject.units OR actualCount == 0 // 0 if no teacher available
    END FOR
  END FOR
  
  // Check Property 2: No intra-day gaps
  FOR EACH section IN result.sections DO
    FOR EACH day IN result.scheduledDays DO
      slots := getScheduledSlots(result.schedule, section.id, day)
      ASSERT NOT hasGapBetweenSlots(slots)
    END FOR
  END FOR
  
  // Check Property 3: No same-day duplicates
  FOR EACH section IN result.sections DO
    FOR EACH day IN result.scheduledDays DO
      subjects := getSubjectsOnDay(result.schedule, section.id, day)
      ASSERT NOT hasDuplicates(subjects)
    END FOR
  END FOR
  
  RETURN true
END FUNCTION
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
FOR ALL scheduleInput WHERE NOT isBugCondition(scheduleInput) DO
  ASSERT autoSchedule_original(scheduleInput) = autoSchedule_fixed(scheduleInput)
END FOR
```

**Testing Approach**: Property-based testing is recommended for preservation checking because:
- It generates many test cases automatically across the input domain (various section configurations, teacher availability patterns, subject unit counts)
- It catches edge cases that manual unit tests might miss (e.g., unusual combinations of teacher availability and subject requirements)
- It provides strong guarantees that behavior is unchanged for all non-buggy inputs (single-unit subjects, PRELIMINARIES, failed assignments)

**Test Plan**: Observe behavior on UNFIXED code first for single-unit subjects, teacher availability restrictions, and PRELIMINARIES scheduling, then write property-based tests capturing that behavior.

**Test Cases**:

1. **Single-Unit Subject Preservation**: Generate schedules with subjects that have 1 unit. Verify the fixed code produces identical placement (same day, same slot, same teacher) as the unfixed code.

2. **Teacher Availability Preservation**: Generate schedules with teachers that have availability restrictions. Verify the fixed code respects the same restrictions as the unfixed code (no assignments to unavailable slots).

3. **PRELIMINARIES Preservation**: Generate schedules for JHS sections with advisory teachers. Verify the fixed code produces identical PRELIMINARIES placement at p1 on Monday-Friday as the unfixed code.

4. **Failed Assignment Preservation**: Generate schedules where no teacher is available for a subject. Verify the fixed code logs the same failed assignment as the unfixed code.

### Unit Tests

- Test exact unit count placement for subjects with 1, 2, 3, 4, 5 units
- Test sequential packing with no gaps for days with 2, 4, 6, 8 subjects
- Test same-day duplicate prevention for subjects with 2, 3, 4 units
- Test edge case: subject with more units than available days (should cap or fail gracefully)
- Test edge case: all teachers unavailable for a subject (should log failed assignment)
- Test edge case: section with no subjects (should skip without crashing)

### Property-Based Tests

- Generate random section configurations (grade, strand, subject counts) and verify all three properties hold (exact units, no gaps, no same-day duplicates)
- Generate random teacher availability patterns and verify preservation of availability restrictions
- Generate random subject unit counts (1-6 units) and verify exact placement counts
- Test across many scenarios to catch edge cases in day distribution, slot selection, and recovery pass logic

### Integration Tests

- Test full schedule generation for a school with 10 JHS sections and 10 SHS sections, verifying all three properties hold for all sections
- Test schedule generation with mixed teacher availability (some teachers available all days, some only certain days)
- Test schedule generation with subjects that have varying unit counts (1-5 units)
- Test that units compliance report in API response accurately reflects actual placements
- Test that failed assignments are logged correctly when subjects cannot be placed
